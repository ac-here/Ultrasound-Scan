function ind = FindMatchingTag( dcmTags, desiredTag, indLowerLimit, indUpperLimit, firstN )
%FINDMATCHINGTAG
%   DESCRIPTION:
%       This function determines if a tag matching a desired tag exists in
%       the DICOM and if so, it returns the tag index relative to a list of
%       all tags in the DICOM. An upper and lower index limit can be
%       specified, which limits the index range that will be searched when
%       looking for the desired tag. If specified, at most only the first N
%       instances where the tag is found will be returned. If no instances
%       of the tag around found, an empty array will be returned.
%   INPUTS:
%       dcmTags:
%           Array returned by the function 'ScanDICOMTags' which summarizes
%           the tags found in the DICOM, as well as related tag
%           information.
%       desiredTag:
%           Array (1x2) indicating the desired tag (group,element), which
%           should be in decimal form (i.e. NOT hexadecimal form).
%       indLowerLimit (optional):
%           Index below which the function will not search for the desired
%           tag (scalar, integer). Default = 0.
%       indUpperLimit (optional):
%           Index above which the function will not search for the desired
%           tag (scalar, integer). Default = inf.
%       firstN (optional):
%           If specified, the function returns at most the first N indices
%           corresponding to where the tag was found between the upper and
%           lower index limits. If the limit is not specified, all
%           instances where the tag was found will be returned.
%           Default = inf.
%   OUTPUTS:
%       ind:
%           The index (indices) relative to the list of dicom tags where
%           the desired tag was found. If no instances were found, an empty
%           array will be returned.
%   EXAMPLE:
%       ind = FindMatchingTag( dcmTags, desiredTag );
%       ind = FindMatchingTag( dcmTags, desiredTag, indLowerLimit );
%       ind = FindMatchingTag( dcmTags, desiredTag, indLowerLimit, indUpperLimit );
%       ind = FindMatchingTag( dcmTags, desiredTag, indLowerLimit, [], firstN );
%       ind = FindMatchingTag( dcmTags, desiredTag, [], [], firstN );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

if nargin<2
    error('ERROR: usage');
end
if nargin<3 || isempty(indLowerLimit)
    indLowerLimit = 1;
end
if nargin<4 || isempty(indUpperLimit)
    indUpperLimit = size(dcmTags,1);
end
if nargin<5 || isempty(firstN)
    firstN = inf;
end
if size(dcmTags,2)<6
    error('ERROR: dcmTags should have six columns');
end
if numel(desiredTag)~=2
    error('ERROR: desiredTag should be a 2-element vector');
end

ind = find( dcmTags(:,1)==desiredTag(1) &...
            dcmTags(:,2)==desiredTag(2) &...
            dcmTags(:,6)>=dcmTags(indLowerLimit,6)  &...
            dcmTags(:,6)<=dcmTags(indUpperLimit,6), firstN ); 

return