function fid = FileSeek2DCMTag( fid,dcmTags,tagInd )
%FILESEEK2DCMTAG
%   DESCRIPTION:
%       This function will move the file identifier to the beginning of the
%       data block for the specified dicom tag.
%   INPUTS:
%       fid:
%           File identifier (generated from fopen function).
%       dcmTags:
%           Array of DICOM tag information generated from ScanDICOMTags
%           function.
%       tagInd:
%           The tag index (relative to list of all tags in the file)
%           corresponding to the data block to where the file identifer
%           will be moved.
%   OUTPUTS:
%       fid:
%           File identifier (updated).
%   EXAMPLE:
%       fid = FileSeek2DCMTag( fid,dcmTags,tagInd );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

if size(dcmTags,2)<6
    error('ERROR: dcmTags should have six columns');
end
if numel(tagInd)~=1
    error('ERROR: tagInd should be a 1-element vector');
end

if( fseek(fid,dcmTags(tagInd,6),'bof') )
    error('ERROR: could not seek to location');
end

return