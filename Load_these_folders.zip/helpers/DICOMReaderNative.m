function volData = DICOMReaderNative( varargin )
%DICOMREADERNATIVE
%   DESCRIPTION:
%       This function reads scan line data from a native 3D ultrasound
%       DICOM file. The scan line data and relevant information needed to
%       reconstruct the scan line data in a physical coordinate space
%       and/or to write a new native DICOM are returned in a structure.
%       This function can read both compressed and uncompressed scan line
%       data. The function will read in all scan line data if not provided
%       with a vector indicating the frames to be read from the file.
%   INPUTS:
%       dcmFn (optional):
%           The file path and name for the native 3D ultrasound DICOM file.
%           If not provided, the user will be asked to specify the file via
%           a graphical interface.
%       frames (optional):
%           Vector indicating the frames to read from the file. Only frames
%           whose frame number does not exceed the maximum number of frames
%           will be read from the file. If not provided, it is assumed that
%           all available frames should be read.
%   OUTPUTS:
%       volData:
%           Structure containing information read from the DICOM file. The
%           structure contains the following fields:
%               rand                : random number used for decryption
%               hash                : hash used for decryption
%               hashDbl             : hash used for decryption
%               timerResolution     : timer resolution (cycles/sec)
%               omniPlaneAngle      : omni plane rotation angle (radians)
%
%               rStart              : start of radial sampling (mm)
%               rEnd                : end of radial sampling (mm)
%               rCount              : number of radial samples
%               rPitch              : pitch of radial samples as stored in volume data block 
%               rRes                : radial sampling resolution (mm)
%               thetaStart          : start of lateral sampling (radians)
%               thetaEnd            : end of lateral sampling (radians)
%               thetaCount          : number of lateral samples
%               thetaPitch          : pitch of lateral samples as stored in volume data block 
%               thetaRes            : lateral sampling resolution (radians)
%               phiStart            : start of elevation sampling (radians)
%               phiEnd              : end of elevation sampling (radians)
%               phiCount            : number of elevations samples
%               phiPitch            : pitch of elevation samples as stored in volume data block 
%               phiRes              : elevation sampling resolution (radians)
%               frameRes            : frame resolution (sec)
%               numFrames           : number of frames
%               bytesPerVolume      : bytes per volume
%               bytesPerHeader      : volume header bytes
%               headers             : volume headers (structure)
%               frameTimes          : frame start times (clock cycles)
%               data                : echo data (scan lines)
%
%               rStartClr           : start of radial sampling, color (mm)
%               rEndClr             : end of radial sampling, color (mm)
%               rCountClr           : number of radial samples, color
%               rPitchClr           : pitch of radial samples as stored in volume data block, color 
%               thetaStartClr       : start of lateral sampling, color (radians) 
%               thetaEndClr         : end of lateral sampling, color (radians) 
%               thetaCountClr       : number of lateral samples, color
%               thetaPitchClr       : pitch of lateral samples as stored in volume data block, color 
%               phiStartClr         : start of elevation sampling, color (radians) 
%               phiEndClr           : end of elevation sampling, color (radians) 
%               phiCountClr         : number of elevation samples, color
%               phiPitchClr         : pitch of elevation samples as stored in volume data block, color 
%               frameResClr         : frame resolution, color (sec)
%               numFramesClr        : number of frames, color
%               bytesPerVolumeClr   : bytes per volume, color
%               bytesPerHeaderClr   : volume header bytes, color
%               headersClr          : volume headers, color (structure)
%               frameTimesClr       : frame start times, color (clock cycles)
%               dataClr             : color data (scan lines)
%
%   EXAMPLES
%       volData = DICOMReaderNative;
%       volData = DICOMReaderNative( dcmFn );
%       volData = DICOMReaderNative( dcmFn, frames );
%       volData = DICOMReaderNative( [],frames );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

%--------------------------------------------------------------------------
%SPECIFIED CONSTANTS
const.tags.seq_item             = [hex2dec('fffe') hex2dec('e000')];
const.tags.seq_item_delim       = [hex2dec('fffe') hex2dec('e00d')];
const.tags.seq_delim            = [hex2dec('fffe') hex2dec('e0dd')];
const.tags.model_name           = [hex2dec('0008') hex2dec('1090')];
const.tags.omni_plane_angle     = [hex2dec('200d') hex2dec('3126')];
const.tags.neo_rand             = [hex2dec('200d') hex2dec('3920')];
const.tags.num_samples          = [hex2dec('200d') hex2dec('3010')];
const.tags.bytes_per_sample     = [hex2dec('200d') hex2dec('3011')];
const.tags.vol_dims             = [hex2dec('200d') hex2dec('3315')];
const.tags.vol_pitch            = [hex2dec('200d') hex2dec('3316')];
const.tags.vol_res              = [hex2dec('200d') hex2dec('3317')];
const.tags.vol_start            = [hex2dec('200d') hex2dec('3318')];
const.tags.depth_start          = [hex2dec('200d') hex2dec('3102')];
const.tags.depth_end            = [hex2dec('200d') hex2dec('3103')];
const.tags.depth_end_alt        = [hex2dec('200d') hex2dec('3121')];
const.tags.lateral_start        = [hex2dec('200d') hex2dec('3104')];
const.tags.lateral_end          = [hex2dec('200d') hex2dec('3105')];
const.tags.elev_start           = [hex2dec('200d') hex2dec('3203')];
const.tags.elev_end             = [hex2dec('200d') hex2dec('3204')];
const.tags.vol_dims_clr         = [hex2dec('200d') hex2dec('3610')];
const.tags.vol_pitch_clr        = [hex2dec('200d') hex2dec('3611')];
const.tags.vol_res_clr          = [hex2dec('200d') hex2dec('3612')];
const.tags.vol_start_clr        = [hex2dec('200d') hex2dec('3613')];
const.tags.depth_start_clr      = [hex2dec('200d') hex2dec('3812')];
const.tags.depth_end_clr        = [hex2dec('200d') hex2dec('3813')];
const.tags.lateral_start_clr    = [hex2dec('200d') hex2dec('3810')];
const.tags.lateral_end_clr      = [hex2dec('200d') hex2dec('3811')];
const.tags.elev_start_clr       = [hex2dec('200d') hex2dec('3203')];
const.tags.elev_end_clr         = [hex2dec('200d') hex2dec('3204')];
const.tags.volume_rate          = [hex2dec('200d') hex2dec('3207')];
const.tags.native_data_type     = [hex2dec('200d') hex2dec('300d')];
const.tags.native_data_stream   = [hex2dec('200d') hex2dec('300e')];
const.tags.compress_native_data = [hex2dec('200d') hex2dec('3cf3')];
const.tags.compress_type        = [hex2dec('200d') hex2dec('3cfa')];
const.tags.native_headers       = [hex2dec('200d') hex2dec('3cfb')];

const.tags.cx.omni_plane_angle     = [hex2dec('200d') hex2dec('1626')];
const.tags.cx.neo_rand             = [hex2dec('200d') hex2dec('1220')];
const.tags.cx.num_samples          = [hex2dec('200d') hex2dec('1010')];
const.tags.cx.bytes_per_sample     = [hex2dec('200d') hex2dec('1011')];
const.tags.cx.vol_dims             = [hex2dec('200d') hex2dec('1915');...
                                      hex2dec('200d') hex2dec('1a15')];
const.tags.cx.vol_pitch            = [hex2dec('200d') hex2dec('1916');...
                                      hex2dec('200d') hex2dec('1a16')];
const.tags.cx.vol_res              = [hex2dec('200d') hex2dec('1917');...
                                      hex2dec('200d') hex2dec('1a17')];
const.tags.cx.vol_start            = [hex2dec('200d') hex2dec('1918');...
                                      hex2dec('200d') hex2dec('1a18')];
const.tags.cx.native_data_type     = [hex2dec('200d') hex2dec('100d')];
const.tags.cx.native_data_stream   = [hex2dec('200d') hex2dec('100e')];
const.tags.cx.compress_native_data = [hex2dec('200d') hex2dec('11f3')];
const.tags.cx.compress_type        = [hex2dec('200d') hex2dec('11fa')];
const.tags.cx.native_headers       = [hex2dec('200d') hex2dec('11fb')];

const.echo_sequence_title       = 'UDM_USD_DATATYPE_DIN_3D_ECHO';
const.color_sequence_title      = 'UDM_USD_DATATYPE_DIN_3D_COLOR_VELOCITY';
const.timerResolutionIE         = 20000;   %20KHz
const.timerResolutionV1         = 1000000; %1 MHz
const.timerResolutionCX         = 1000000; %1 MHz
const.hash_magic                = int32( 5073 );

%INITIALIZE STRUCTURE FOR RETURN
volData.rand                = []; %int
volData.hash                = []; %int
volData.hashDbl             = []; %double
volData.timerResolution     = []; %double
volData.omniPlaneAngle      = []; %double

volData.rStart              = []; %double
volData.rEnd                = []; %double
volData.rCount              = []; %int
volData.rPitch              = []; %int
volData.rRes                = []; %double
volData.thetaStart          = []; %double
volData.thetaEnd            = []; %double
volData.thetaCount          = []; %int
volData.thetaPitch          = []; %int
volData.thetaRes            = []; %double
volData.phiStart            = []; %double
volData.phiEnd              = []; %double
volData.phiCount            = []; %int
volData.phiPitch            = []; %int
volData.phiRes              = []; %double
volData.frameRes            = []; %double
volData.numFrames           = []; %int
volData.bytesPerVolume      = []; %int
volData.bytesPerHeader      = []; %int
volData.headers             = []; %(structure)
volData.frameTimes          = []; %double
volData.data                = []; %unsigned char

volData.rStartClr           = []; %double
volData.rEndClr             = []; %double
volData.rCountClr           = []; %int
volData.rPitchClr           = []; %int
volData.rResClr             = []; %double
volData.thetaStartClr       = []; %double
volData.thetaEndClr         = []; %double
volData.thetaCountClr       = []; %int
volData.thetaPitchClr       = []; %int
volData.thetaResClr         = []; %double
volData.phiStartClr         = []; %double
volData.phiEndClr           = []; %double
volData.phiCountClr         = []; %int
volData.phiPitchClr         = []; %int
volData.phiResClr           = []; %double
volData.frameResClr         = []; %double
volData.numFramesClr        = []; %int
volData.bytesPerVolumeClr   = []; %int
volData.bytesPerHeaderClr   = []; %int
volData.headersClr          = []; %(structure)
volData.frameTimesClr       = []; %double
volData.dataClr             = []; %signed char

%--------------------------------------------------------------------------
%resolve inputs and error check
frames = [];
dcmFn = [];
if nargin
    dcmFn = varargin{1};
end
if isempty(dcmFn)
    [fn,pn] = uigetfile(fullfile( fileparts(mfilename('fullpath')),'*.*' ),'Select 3D DICOM:');
    if isequal(pn,0)||isequal(fn,0)
        return;
    end
    dcmFn = fullfile(pn,fn);
end
if ~exist(dcmFn,'file')
    error('ERROR: invalid file (does not exist)');
end
if nargin>1
    frames = varargin{2};
    if isempty(frames) || ~isnumeric(frames)
        error('ERROR: invalid frame number(s)');
    end
end
    
%--------------------------------------------------------------------------
%scan all dicom tags in file
dcmTags = ScanDICOMTags( dcmFn,0,const.tags.model_name );

%open file for reading
fid = fopen( dcmFn,'r','l' );
if fid==-1
    error(['ERROR: File ''' filename ''' could not be opened for reading!']);
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read hardware and appropriately assign timer resolution
indTarget = FindMatchingTag( dcmTags,const.tags.model_name,[],[],1 );
if isempty(indTarget)
    return;
end
fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
fmt = sprintf('%%%dc',dcmTags(indTarget,5));
modelName = fscanf(fid,fmt,1);
volData.timerResolution = const.timerResolutionV1;
if strncmpi(modelName,'ie',2)
    volData.timerResolution = const.timerResolutionIE;
elseif strncmpi(modelName,'cx',2)
    volData.timerResolution = const.timerResolutionCX;
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%parse the rest of the file based on the model (iE, EPIQ, or CX)
if strncmpi(modelName,'cx',2)
    volData = ParseCX( fid,dcmFn,frames,const,volData );
else
    volData = ParseIEorEPIQ( fid,dcmFn,frames,const,volData );
end

return
%==========================================================================
function volData = ParseIEorEPIQ( fid,dcmFn,frames,const,volData )
%Parse 3D volume information from iE33 or EPIQ DICOM files

dcmTags = ScanDICOMTags(dcmFn);

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in omni plane angle
indTarget = FindMatchingTag( dcmTags,const.tags.omni_plane_angle,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    [volData.omniPlaneAngle,fid] = ReadDouble( fid,dcmTags(indTarget,5) );
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in random number
indTarget = FindMatchingTag( dcmTags,const.tags.neo_rand,[],[],1 );
if isempty(indTarget)
    return;
end
fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
[volData.rand,fid] = ReadInteger( fid,dcmTags(indTarget,5) );

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%compute hash
volData.hash = volData.rand * const.hash_magic;
volData.hashDbl = double(volData.rand)/double(const.hash_magic);

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume dimensions (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.vol_dims,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    valsEncrypt = sscanf(str,'%d\\%d\\%d\\%d');
    vals = typecast( bitxor( typecast( int32(valsEncrypt),'uint32' ),typecast( volData.hash,'uint32' ) ), 'int32' );
    volData.rCount      = vals(1);
    volData.thetaCount  = vals(2);
    volData.phiCount    = vals(3);
end

indTarget = FindMatchingTag( dcmTags,const.tags.vol_dims_clr,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    valsEncrypt = sscanf(str,'%d\\%d\\%d\\%d');
    vals = typecast( bitxor( typecast( int32(valsEncrypt),'uint32' ),typecast( volData.hash,'uint32' ) ), 'int32' );
    volData.rCountClr       = vals(1);
    volData.thetaCountClr   = vals(2);
    volData.phiCountClr     = vals(3);
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume pitch (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.vol_pitch,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    valsEncrypt = sscanf(str,'%d\\%d\\%d\\%d');
    vals = typecast( bitxor( typecast( int32(valsEncrypt),'uint32' ),typecast( volData.hash,'uint32' ) ), 'int32' );
    volData.rPitch      = vals(1);
    volData.thetaPitch  = vals(2);
    volData.phiPitch    = vals(3);
end

indTarget = FindMatchingTag( dcmTags,const.tags.vol_pitch_clr,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    valsEncrypt = sscanf(str,'%d\\%d\\%d\\%d');
    vals = typecast( bitxor( typecast( int32(valsEncrypt),'uint32' ),typecast( volData.hash,'uint32' ) ), 'int32' );
    volData.rPitchClr       = vals(1);
    volData.thetaPitchClr   = vals(2);
    volData.phiPitchClr     = vals(3);
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume resolution (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.vol_res,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    vals = sscanf(str,'%f\\%f\\%f\\%f')/volData.hashDbl;
    volData.rRes        = vals(1);
    volData.thetaRes    = vals(2);
    volData.phiRes      = vals(3);
    volData.frameRes    = vals(4);
end

indTarget = FindMatchingTag( dcmTags,const.tags.vol_res_clr,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    vals = sscanf(str,'%f\\%f\\%f\\%f')/volData.hashDbl;
    volData.rResClr     = vals(1);
    volData.thetaResClr = vals(2);
    volData.phiResClr   = vals(3);
    volData.frameResClr = vals(4);
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume start positions (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.vol_start,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    vals = sscanf(str,'%f\\%f\\%f\\%f')/volData.hashDbl;
    volData.rStart      = -vals(1);
    volData.thetaStart  = -vals(2);
    volData.phiStart    = -vals(3);
    
    volData.rEnd     = volData.rStart     + (volData.rRes    *double(volData.rCount    -1));
    volData.thetaEnd = volData.thetaStart + (volData.thetaRes*double(volData.thetaCount-1));
    volData.phiEnd   = volData.phiStart   + (volData.phiRes  *double(volData.phiCount  -1));
end

indTarget = FindMatchingTag( dcmTags,const.tags.vol_start_clr,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    vals = sscanf(str,'%f\\%f\\%f\\%f')/volData.hashDbl;
    volData.rStartClr       = -vals(1);
    volData.thetaStartClr   = -vals(2);
    volData.phiStartClr     = -vals(3);
    
    volData.rEndClr     = volData.rStartClr     + (volData.rResClr    *double(volData.rCountClr    )); %not supposed to have -1
    volData.thetaEndClr = volData.thetaStartClr + (volData.thetaResClr*double(volData.thetaCountClr)); %not supposed to have -1
    volData.phiEndClr   = volData.phiStartClr   + (volData.phiResClr  *double(volData.phiCountClr  )); %not supposed to have -1
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in echo and/or color data
if volData.rCount>0
    [fid,volData] = ReadVolumeData( fid,dcmTags,frames,const,1,volData );
end
if volData.rCountClr>0
    [fid,volData] = ReadVolumeData( fid,dcmTags,frames,const,0,volData );
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%close file
fclose(fid);

return
%==========================================================================
function volData = ParseCX( fid,dcmFn,frames,const,volData )
%Parse 3D volume information from CX-50 DICOM files

dcmTags = ScanDICOMTags(dcmFn,0,[hex2dec('200d') hex2dec('1a14')]);
if dcmTags(end,1)==hex2dec('200d') &&...
   dcmTags(end,2)==hex2dec('1a14')
    %found tag (200d,1a14)... this means (200d,1a15) is lengthy sequence...
    %do not read any further
else
    %did not find (200d,1a14)... therefore read whole file so can find
    %other needed information
    dcmTags = ScanDICOMTags(dcmFn);
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in omni plane angle
indTarget = FindMatchingTag( dcmTags,const.tags.cx.omni_plane_angle,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    [volData.omniPlaneAngle,fid] = ReadDouble( fid,dcmTags(indTarget,5) );
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in random number
indTarget = FindMatchingTag( dcmTags,const.tags.cx.neo_rand,[],[],1 );
if isempty(indTarget)
    volData.rand = int32(81660);
else
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    [volData.rand,fid] = ReadInteger( fid,dcmTags(indTarget,5) );
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%compute hash
volData.hash = volData.rand * const.hash_magic;
volData.hashDbl = double(volData.rand)/double(const.hash_magic);

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume dimensions (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_dims(1,:),[],[],1 );
if isempty(indTarget)
    indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_dims(2,:),[],[],1 );
end
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    valsEncrypt = sscanf(str,'%d\\%d\\%d\\%d');
    if ~isempty(valsEncrypt)
        vals = typecast( bitxor( typecast( int32(valsEncrypt),'uint32' ),typecast( volData.hash,'uint32' ) ), 'int32' );
        volData.rCount      = vals(1);
        volData.thetaCount  = vals(2);
        volData.phiCount    = vals(3);
    end
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume pitch (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_pitch(1,:),[],[],1 );
if isempty(indTarget)
    indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_pitch(2,:),[],[],1 );
end

if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    valsEncrypt = sscanf(str,'%d\\%d\\%d\\%d');
    if ~isempty(valsEncrypt)
        vals = typecast( bitxor( typecast( int32(valsEncrypt),'uint32' ),typecast( volData.hash,'uint32' ) ), 'int32' );
        volData.rPitch      = vals(1);
        volData.thetaPitch  = vals(2);
        volData.phiPitch    = vals(3);
    end
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume resolution (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_res(1,:),[],[],1 );
if isempty(indTarget)
    indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_res(2,:),[],[],1 );
end

if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    vals = sscanf(str,'%f\\%f\\%f\\%f')/volData.hashDbl;
    if ~isempty(vals)
        volData.rRes        = vals(1);
        volData.thetaRes    = vals(2);
        volData.phiRes      = vals(3);
        volData.frameRes    = vals(4);
    end
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in volume start positions (bw / color)
indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_start(1,:),[],[],1 );
if isempty(indTarget)
    indTarget = FindMatchingTag( dcmTags,const.tags.cx.vol_start(2,:),[],[],1 );
end

if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    str = fread(fid,dcmTags(indTarget,5),'uint8=>char');
    vals = sscanf(str,'%f\\%f\\%f\\%f')/volData.hashDbl;
    if ~isempty(vals)
        volData.rStart      = -vals(1);
        volData.thetaStart  = -vals(2);
        volData.phiStart    = -vals(3);

        volData.rEnd     = volData.rStart     + (volData.rRes    *double(volData.rCount    -1));
        volData.thetaEnd = volData.thetaStart + (volData.thetaRes*double(volData.thetaCount-1));
        volData.phiEnd   = volData.phiStart   + (volData.phiRes  *double(volData.phiCount  -1));
    end
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%read in echo and/or color data
tempConst = const;
tempConst.tags.num_samples          = const.tags.cx.num_samples;
tempConst.tags.bytes_per_sample     = const.tags.cx.bytes_per_sample;
tempConst.tags.native_data_type     = const.tags.cx.native_data_type;
tempConst.tags.native_data_stream   = const.tags.cx.native_data_stream;
tempConst.tags.compress_native_data = const.tags.cx.compress_native_data;
tempConst.tags.compress_type        = const.tags.cx.compress_type;
tempConst.tags.native_headers       = const.tags.cx.native_headers;

if volData.rCount>0
    [fid,volData] = ReadVolumeData( fid,dcmTags,frames,tempConst,1,volData );
end

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
%close file
fclose(fid);

return
%==========================================================================
function [val,fid] = ReadDouble( fid,valueLength )
%READDOUBLE
%   DESCRIPTION:
%       Read a value of class double from file.
%   INPUTS:
%       fid:
%           File identifier.
%       valueLength:
%           Number of characters in the file which specify the double
%           value.
%   OUTPUTS:
%       val:
%           Value of type double read from the file.
%       fid:
%           File identifier.
%   EXAMPLE:
%       [val,fid] = ReadDouble( fid,valueLength );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

fmt = sprintf('%%%df',valueLength);
val = double( fscanf(fid,fmt,1) );

return
%==========================================================================
function [val,fid] = ReadInteger( fid,valueLength )
%READINTEGER
%   DESCRIPTION:
%       Read a value of class integer from file.
%   INPUTS:
%       fid:
%           File identifier.
%       valueLength:
%           Number of characters in the file which specify the integer
%           value.
%   OUTPUTS:
%       val:
%           Value of type integer read from the file.
%       fid:
%           File identifier.
%   EXAMPLE:
%       [val,fid] = ReadInteger( fid,valueLength );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

fmt = sprintf('%%%dd',valueLength);
val = int32( fscanf(fid,fmt,1) );

return
%==========================================================================
function [fid,hdr] = ReadVolumeHeader( fid,headerSize )
%READVOLUMEHEADER
%   DESCRIPTION:
%       This function reads the volume header from a DICOM file. The volume
%       header should be either 16 or 32 bytes in size. The information
%       in the header is returned in a structure.
%   INPUTS:
%       fid:
%           File identifier.
%       headerSize:
%           Scalar value indicating header size. Valid values are either 16
%           or 32.
%   OUTPUTS:
%       fid:
%           File identifier.
%       hdr:
%           Structure with the following fields, whose class/size varies
%           depending on the size of the header.
%           Field        |  16-byte  |  32-byte
%           -------------|-----------|----------------
%           frameTime    |  uint32   |  uint64
%           reserved1    |  uint16   |  uint16
%           headerTag    |  uint16   |  uint16 (bit field, headerTag:14, elastoSign:2)
%           dataType     |  uchar    |  uchar
%           reserved2    |  uchar    |  uchar
%           dataFormat   |  uint16   |  uint16
%           dataSize     |  uint32   |  uint32
%   EXAMPLE:
%       [fid,hdr] = ReadVolumeHeader( fid,headerSize );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

if headerSize==16
    %read in 16-byte header
    
    %frame time     (unsigned long int, 4 bytes)
    hdr.frameTime  = fread( fid,1,'uint32=>uint32' );
    
    %reserved       (unsigned short int, 2 bytes)
    hdr.reserved1  = fread( fid,1,'uint16=>uint16' );
    
    %headertag      (unsigned short int, 2 bytes)
    hdr.headerTag  = fread( fid,1,'uint16=>uint16' );
    
    %data type      (uchar, 1 byte)
    hdr.dataType   = fread( fid,1,'uint8=>uint8' );
    
    %reserved       (uchar, 1 byte)
    hdr.reserved2  = fread( fid,1,'uint8=>uint8' );
    
    %data format    (unsigned short int, 2 bytes)
    hdr.dataFormat = fread( fid,1,'uint16=>uint16' );
    
    %data size      (unsigned long int, 4 bytes)
    hdr.dataSize   = fread( fid,1,'uint32=>uint32' );
    %NOTE: it is observed that dataSize = rPitch*thetaPitch*phiCount
    
elseif headerSize==32
    %read in 32-byte header
    
    %frame time     (uint64, 8 bytes)
    hdr.frameTime  = fread( fid,1,'uint64=>uint64' );
    
    %reserved       (unsigned short int, 2 bytes)
    hdr.reserved1  = fread( fid,1,'uint16=>uint16' );
    
    %headertag (:14) + elastosign (:2) (unsigned short int, 2 bytes)
    hdr.headerTag  = fread( fid,1,'uint16=>uint16' );
    
    %data type      (uchar, 1 byte)
    hdr.dataType   = fread( fid,1,'uint8=>uint8' );
    
    %reserved       (uchar, 1 byte)
    hdr.reserved2  = fread( fid,1,'uint8=>uint8' );
    
    %data format    (unsigned short int, 2 bytes)
    hdr.dataFormat = fread( fid,1,'uint16=>uint16' );
    
    %data size      (unsigned long int, 4 bytes)
    hdr.dataSize   = fread( fid,1,'uint32=>uint32' );
    %NOTE: it is observed that dataSize = rPitch*thetaPitch*phiCount
    
    %padding        (char, 12 bytes)
    fread( fid,12,'uint8' );
    
else
    error('ERROR: unknown header format for specified size');
end

return
%==========================================================================
function [fid,volData] = ReadVolumeData( fid,dcmTags,frames,const,isEcho,volData )
%READVOLUMEDATA
%   DESCRIPTION:
%       This functions reads the scan line data in a DICOM. Both compressed
%       and uncompressed scan line data can be read. The volume data, which
%       includes the scan line data plus any other relevant information
%       stored in the same sequence as the scan line data, is returned in
%       the structure as initialized in DICOMReaderSL.
%   INPUTS:
%       fid:
%           File identifier for DICOM file containing scan line data.
%       dcmTags:
%           Array returned by the function 'ScanDICOMTags' which summarizes
%           the tags found in the DICOM, as well as related tag
%           information.
%       frames:
%           Vector indicating the frames for which data should be read.
%       const:
%           Structure of pre-specified constants initialized in
%           DICOMReaderSL.
%       isEcho:
%           Flag indicating if echo data (vs. color) should be read.
%       volData:
%           Structure as initialized in DICOMReaderSL which stores relevant
%           information surrounding the ultrasound acquisition (i.e. scan
%           line information and acquisition parameters).
%   OUTPUTS:
%       volData:
%           Structure as initialized in DICOMReaderSL which stores relevant
%           information surrounding the ultrasound acquisition (i.e. scan
%           line information and acquisition parameters).
%   EXAMPLES:
%       volData = ReadVolumeData(fid,dcmTags,frames,const,isEcho,volData);
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

%find location of all sequence titles and find the one corresponding to the
%desired data
if isEcho
    targetTitle = const.echo_sequence_title;
else
    targetTitle = const.color_sequence_title;
end
indPossible = FindMatchingTag( dcmTags,const.tags.native_data_type );

for n = 1:numel(indPossible)
    %seek to location in file of sequence
    fid = FileSeek2DCMTag( fid,dcmTags,indPossible(n) );
    
    %read title
    tempStr = fread( fid,dcmTags(indPossible(n),5),'uint8=>char' );
    tempStr = tempStr(:)';
    
    %compare strings to determine if it is the desired sequence
    if( strcmpi(deblank(tempStr),deblank(targetTitle)) )
        %found echo data...
        
        %find sequence start
        indSeqStart = FindMatchingTag( dcmTags,const.tags.seq_item,indPossible(n),[],1 );
        
                        
        %find sequence end
        indSeqEnd = FindMatchingTag( dcmTags,const.tags.seq_item_delim,indSeqStart,[],1 );
        
                      
        %read number of frames
        indTarget = FindMatchingTag( dcmTags,const.tags.num_samples,indSeqStart,indSeqEnd,1 );
        if isempty(indTarget)
            error('ERROR: could not find number of frames');
        end
        fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
        [tempNumFrames,fid] = ReadInteger( fid,dcmTags(indTarget,5) );
        if isempty(frames)
            frames = 1:tempNumFrames;
        else
            frames(frames>tempNumFrames) = [];
            if isempty(frames)
                error('ERROR: all specified frames were out of range');
            end
        end
        
        
        %read bytes per volume
        indTarget = FindMatchingTag( dcmTags,const.tags.bytes_per_sample,indSeqStart,indSeqEnd,1 );
        if isempty(indTarget)
            error('ERROR: could not find number of samples');
        end
        fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
        [tempBytesPerVolume,fid] = ReadInteger( fid,dcmTags(indTarget,5) );
        
        
        %determine if compression type is in sequence
        indCompType = FindMatchingTag( dcmTags,const.tags.compress_type,indSeqStart,indSeqEnd,1 );
        compType = [];
        if ~isempty(indCompType)
            %read in compression type
            fid = FileSeek2DCMTag( fid,dcmTags,indCompType );
            compType = fread(fid,dcmTags(indCompType,5),'uint8=>char');
            compType = compType(:)';
        end
        
        
        %determine if native headers are in sequence
        %(used later to determine how to read volume data)
        indHeaders = FindMatchingTag( dcmTags,const.tags.native_headers,indSeqStart,indSeqEnd,1 );
        tempVolHeaderBytes = 16;
        if ~isempty(indHeaders)
            tempVolHeaderBytes = dcmTags(indHeaders,5)/tempNumFrames;
            
            %eventually remove this section of the conditional
            tempHdrs = {};
            %seek to location at the beginning of the data block
            fid = FileSeek2DCMTag( fid,dcmTags,indHeaders );
            for tnf = 1:tempNumFrames
                [fid,tempHdrs{tnf}] = ReadVolumeHeader( fid,tempVolHeaderBytes );
            end
        end
        
        
        %determine type of data (compressed vs. uncompressed) present
        indUnCompData = FindMatchingTag( dcmTags,const.tags.native_data_stream,  indSeqStart,indSeqEnd,1 );
        indCompData   = FindMatchingTag( dcmTags,const.tags.compress_native_data,indSeqStart,indSeqEnd,1 );
        if ~isempty(indUnCompData) && ~isempty(indCompData)
            error('ERROR: uncompressed and compressed data found');
        end
        if isempty(indUnCompData) && isempty(indCompData)
            error('ERROR: neither uncompressed nor compressed data found');
        end
        
        
        %record sequence information read from file and initialize volume
        %storage
        if isEcho
            volData.numFrames = tempNumFrames;
            volData.bytesPerVolume = tempBytesPerVolume;
            volData.bytesPerHeader = tempVolHeaderBytes;
            volData.frameTimes = zeros(1,numel(frames));
            volData.data = zeros(volData.rCount,volData.thetaCount,volData.phiCount,numel(frames),'uint8');
            nSamples = volData.rPitch * volData.thetaPitch * volData.phiPitch;
        else
            volData.numFramesClr = tempNumFrames;
            volData.bytesPerVolumeClr = tempBytesPerVolume;
            volData.bytesPerHeaderClr = tempVolHeaderBytes;
            volData.frameTimesClr = zeros(1,numel(frames));
            volData.dataClr = zeros(volData.rCountClr,volData.thetaCountClr,volData.phiCountClr,numel(frames),'int8');
            nSamples = volData.rPitchClr * volData.thetaPitchClr * volData.phiPitchClr;
        end
        
        
        %read in volume data
        if ~isempty(indUnCompData)
            %read in UNCOMPRESSED data
            
            %seek to location at the beginning of the data block
            fid = FileSeek2DCMTag( fid,dcmTags,indUnCompData );
            startPos = ftell(fid);
            
            %read in headers and volume data
            for f = 1:numel(frames)
                %seek to file location for desired frame
                fseek( fid,startPos + volData.bytesPerVolume*(frames(f)-1),'bof' );
                
                %read in header
                [fid,tempHeader] = ReadVolumeHeader(fid,tempVolHeaderBytes);
                if false
                    fprintf('Header %d:\n',f);
                    fprintf('   Frame Time : %d\n',tempHeader.frameTime);
                    fprintf('   Reserved_1 : %d\n',tempHeader.reserved1);
                    fprintf('   Header Tag : %d\n',tempHeader.headerTag);
                    fprintf('   Data Type  : %d\n',tempHeader.dataType);
                    fprintf('   Reserved_2 : %d\n',tempHeader.reserved2);
                    fprintf('   Data Format: %d\n',tempHeader.dataFormat);
                    fprintf('   Data Size  : %d\n',tempHeader.dataSize);
                end
                
                %read volume data and store volume data and volume header
                if isEcho
                    tempData = fread(fid,nSamples,'uint8');
                    tempData = reshape(tempData,volData.rPitch,volData.thetaPitch,volData.phiPitch);
                    volData.data(:,:,:,f) = uint8( tempData(1:volData.rCount,1:volData.thetaCount,1:volData.phiCount) );
                    
                    volData.headers{f} = tempHeader;
                    volData.frameTimes(f) = double(tempHeader.frameTime);
                else
                    tempData = fread(fid,nSamples,'int8');
                    tempData = reshape(tempData,volData.rPitchClr,volData.thetaPitchClr,volData.phiPitchClr);
                    volData.dataClr(:,:,:,f) = int8( tempData(1:volData.rCountClr,1:volData.thetaCountClr,1:volData.phiCountClr) );
                    
                    volData.headersClr{f} = tempHeader;
                    volData.frameTimesClr(f) = double(tempHeader.frameTime);
                end
            end
            
        else
            %read in COMPRESSED data
            
            %check that compression method is ZLIB, otherwise throw error
            if ~strcmpi(compType,'ZLib')
                error('ERROR: unknown compression type');
            end
            
            %seek to location at the beginning of the data block
            fid = FileSeek2DCMTag( fid,dcmTags,indCompData );
            startPos = ftell(fid);
            
            %read in number of bytes of data
            %(NOTE: this may not coincide with the value length as the
            %       value length has to be an even number)
            nBytesData = fread(fid,1,'uint32');
            
            %read in number of frames
            numFramesHdr = fread(fid,1,'uint32');
            
            %read in offset table
            offsets = zeros(1,tempNumFrames);
            for f = 1:tempNumFrames
                offsets(f) = fread(fid,1,'uint32');
            end
            
            %read in headers and volume data and uncompress data
            encounteredDataReadProblems = false;
            for f = 1:numel(frames)
                %seek to file location for desired frame
                fseek( fid,startPos + offsets(frames(f)),'bof' );
                
                %read in header
                [fid,tempHeader] = ReadVolumeHeader(fid,tempVolHeaderBytes);
                if false
                    fprintf('Header %d:\n',f);
                    fprintf('   Frame Time : %d\n',tempHeader.frameTime);
                    fprintf('   Reserved_1 : %d\n',tempHeader.reserved1);
                    fprintf('   Header Tag : %d\n',tempHeader.headerTag);
                    fprintf('   Data Type  : %d\n',tempHeader.dataType);
                    fprintf('   Reserved_2 : %d\n',tempHeader.reserved2);
                    fprintf('   Data Format: %d\n',tempHeader.dataFormat);
                    fprintf('   Data Size  : %d\n',tempHeader.dataSize);
                end
                
                %read in volume data and record header
                if frames(f)<tempNumFrames
                    nBytes2Read = offsets(frames(f)+1)-offsets(frames(f))-tempVolHeaderBytes;
                else
                    nBytes2Read = nBytesData-offsets(frames(f))-tempVolHeaderBytes;
                end
                tempData = fread(fid,nBytes2Read,'uint8');
                try
                    tempData = ZLibDecompress( tempData );
                catch
                    encounteredDataReadProblems = true;
                    tempData = [];
                end

                if isEcho
                    if ~encounteredDataReadProblems
                        tempData = reshape(tempData(1:nSamples),volData.rPitch,volData.thetaPitch,volData.phiPitch);
                        volData.data(:,:,:,f) = uint8( tempData(1:volData.rCount,1:volData.thetaCount,1:volData.phiCount) );
                    end
                    volData.headers{f} = tempHeader;
                    volData.frameTimes(f) = double(tempHeader.frameTime);
                else
                    if ~encounteredDataReadProblems
                        tempData = reshape( typecast(tempData(1:nSamples),'int8'),volData.rPitchClr,volData.thetaPitchClr,volData.phiPitchClr);
                        volData.dataClr(:,:,:,f) = tempData(1:volData.rCountClr,1:volData.thetaCountClr,1:volData.phiCountClr);
                    end
                    volData.headersClr{f} = tempHeader;
                    volData.frameTimesClr(f) = double(tempHeader.frameTime);
                end
            end
            if encounteredDataReadProblems
                if isEcho
                    volData.data = [];
                else
                    volData.dataClr = [];
                end
            end
        end
        
        %if go to this point then found data... break from loop
        break;
    end
end

return
%==========================================================================