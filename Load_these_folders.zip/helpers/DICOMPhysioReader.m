function physioData = DICOMPhysioReader( varargin )
%DICOMPHYSIOREADER
%   DESCRIPTION:
%       This function parses the physio information from a native
%       ultrasound DICOM (iU/iE/Voyager). The information is returned in a
%       structure, and includes information such as the physio timestamps,
%       waveforms, and detected R-wave peaks.
%
%       Note that this function is designed for later versions of iU/iE and
%       for Voyager. Earlier versions of iU/iE may not be read correctly in
%       that multiple ECG traces for sub-volume acquisitions may not be read
%       correctly, causing errors in the returned channels and heart rate.
%   INPUTS:
%       dcmFn (optional):
%           The file path and name for the native 3D ultrasound DICOM file.
%           If not provided, the user will be asked to specify the file via
%           a graphical interface.
%   OUTPUTS:
%       physioData:
%           Structure containing information read from the DICOM file. The
%           structure contains the following fields:
%             numTraces        : number of ECG traces (T)
%             numSamples       : number of physio samples (N)
%             bytesPerSample   : number of bytes per sample
%             headers          : headers as read from the file
%             bytesPerHeader   : bytes per header
%             timerResolution  : timer resolution (cyles/second)
%             time             : sample timestamp
%             channels         : recorded channels (Nx(T+2) array)
%             heartRate        : recorded heart rate (BPM)
%             isRPeak          : flag (Nx1) indicating locations of R-wave peaks
%             isEndSystole     : flag (Nx1) indicating locations of ES
%   EXAMPLES
%       physioData = DICOMPhysioReader;
%       physioData = DICOMPhysioReader( dcmFn );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

%--------------------------------------------------------------------------
%SPECIFIED CONSTANTS
const.tags.seq_item             = [hex2dec('fffe') hex2dec('e000')];
const.tags.seq_item_delim       = [hex2dec('fffe') hex2dec('e00d')];
const.tags.seq_delim            = [hex2dec('fffe') hex2dec('e0dd')];
const.tags.model_name           = [hex2dec('0008') hex2dec('1090')];

const.tags.num_samples          = [hex2dec('200d') hex2dec('3010')];
const.tags.bytes_per_sample     = [hex2dec('200d') hex2dec('3011')];
const.tags.native_data_type     = [hex2dec('200d') hex2dec('300d')];
const.tags.native_data_stream   = [hex2dec('200d') hex2dec('300e')];
const.tags.num_subvolumes       = [hex2dec('200d') hex2dec('3978')];
const.tags.compress_native_data = [hex2dec('200d') hex2dec('3cf3')];
const.tags.compress_type        = [hex2dec('200d') hex2dec('3cfa')];
const.tags.native_headers       = [hex2dec('200d') hex2dec('3cfb')];

const.tags.cx.num_samples          = [hex2dec('200d') hex2dec('1010')];
const.tags.cx.bytes_per_sample     = [hex2dec('200d') hex2dec('1011')];
const.tags.cx.native_data_type     = [hex2dec('200d') hex2dec('100d')];
const.tags.cx.native_data_stream   = [hex2dec('200d') hex2dec('100e')];
const.tags.cx.num_subvolumes       = [hex2dec('200d') hex2dec('1278')];
const.tags.cx.compress_native_data = [hex2dec('200d') hex2dec('11f3')];
const.tags.cx.compress_type        = [hex2dec('200d') hex2dec('11fa')];
const.tags.cx.native_headers       = [hex2dec('200d') hex2dec('11fb')];

const.timerResolutionIE         = 20000;   %20KHz
const.timerResolutionV1         = 1000000; %1 MHz
const.timerResolutionCX         = 1000000; %1 MHz
const.physio_sequence_title     = 'UDM_USD_DATATYPE_DIN_PHYSIO ';

%INITIALIZE STRUCTURE FOR RETURN
physioData.numTraces        = [];
physioData.numSamples       = [];
physioData.bytesPerSample   = [];
physioData.headers          = {};
physioData.bytesPerHeader   = [];
physioData.timerResolution  = [];
physioData.time             = [];
physioData.channels         = [];
physioData.heartRate        = [];
physioData.isRPeak          = [];
physioData.isEndSystole     = [];

%--------------------------------------------------------------------------
%resolve inputs and error check
dcmFn = [];
if nargin
    dcmFn = varargin{1};
end
if isempty(dcmFn)
    [fn,pn] = uigetfile(fullfile( fileparts(mfilename('fullpath')),'*.*' ),'Select 3D DICOM:');
    if isequal(pn,0)||isequal(fn,0)
        return;
    end
    dcmFn = fullfile(pn,fn);
end
if ~exist(dcmFn,'file')
    error('ERROR: invalid file (does not exist)');
end
    
%--------------------------------------------------------------------------
%scan all dicom tags in file
dcmTags = ScanDICOMTags( dcmFn,0,const.tags.model_name );

%--------------------------------------------------------------------------
%open file for reading
fid = fopen( dcmFn,'r','l' );
if fid==-1
    error(['ERROR: File ''' filename ''' could not be opened for reading!']);
end

%--------------------------------------------------------------------------
%read hardware and appropriately assign timer resolution
indTarget = FindMatchingTag( dcmTags,const.tags.model_name,[],[],1 );
fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
fmt = sprintf('%%%dc',dcmTags(indTarget,5));
modelName = fscanf(fid,fmt,1);
physioData.timerResolution = const.timerResolutionV1;
if strncmpi(modelName,'ie',2) || strncmpi(modelName,'iu',2)
    physioData.timerResolution = const.timerResolutionIE;
elseif strncmpi(modelName,'cx',2)
    physioData.timerResolution = const.timerResolutionCX;
end

%--------------------------------------------------------------------------
%parse the rest of the file based on the model (iE, EPIQ, or CX)
if strncmpi(modelName,'cx',2)
    physioData = ParseCX( fid,dcmFn,const,physioData );
else
    physioData = ParseIEorEPIQ( fid,dcmFn,const,physioData );
end

return
%==========================================================================
function physioData = ParseIEorEPIQ( fid,dcmFn,const,physioData )

dcmTags = ScanDICOMTags(dcmFn);

%--------------------------------------------------------------------------
%read in number of subvolumes
physioData.numTraces = 1;
indTarget = FindMatchingTag( dcmTags,const.tags.num_subvolumes,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    [nSubVols,fid] = ReadInteger( fid,dcmTags(indTarget,5) );
    physioData.numTraces = nSubVols;
end

%--------------------------------------------------------------------------
%read in physio data
[fid,physioData] = ReadPhysioData( fid,dcmTags,const,physioData );

%--------------------------------------------------------------------------
%close file
fclose(fid);

return
%==========================================================================
function physioData = ParseCX( fid,dcmFn,const,physioData )

dcmTags = ScanDICOMTags(dcmFn,0,[hex2dec('200d') hex2dec('1a14')]);
if dcmTags(end,1)==hex2dec('200d') &&...
   dcmTags(end,2)==hex2dec('1a14')
    %found tag (200d,1a14)... this means (200d,1a15) is lengthy sequence...
    %do not read any further
else
    %did not find (200d,1a14)... therefore read whole file so can find
    %other needed information
    dcmTags = ScanDICOMTags(dcmFn);
end

tempConst = const;
tempConst.tags.num_samples       	= const.tags.cx.num_samples;
tempConst.tags.bytes_per_sample  	= const.tags.cx.bytes_per_sample;
tempConst.tags.native_data_type 	= const.tags.cx.native_data_type;
tempConst.tags.native_data_stream 	= const.tags.cx.native_data_stream;
tempConst.tags.num_subvolumes   	= const.tags.cx.num_subvolumes;
tempConst.tags.compress_native_data	= const.tags.cx.compress_native_data;
tempConst.tags.compress_type     	= const.tags.cx.compress_type;
tempConst.tags.native_headers   	= const.tags.cx.native_headers;

%--------------------------------------------------------------------------
%read in number of subvolumes
physioData.numTraces = 1;
indTarget = FindMatchingTag( dcmTags,tempConst.tags.num_subvolumes,[],[],1 );
if ~isempty(indTarget)
    fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
    [nSubVols,fid] = ReadInteger( fid,dcmTags(indTarget,5) );
    physioData.numTraces = nSubVols;
end

%--------------------------------------------------------------------------
%read in physio data
[fid,physioData] = ReadPhysioData( fid,dcmTags,tempConst,physioData );

%--------------------------------------------------------------------------
%close file
fclose(fid);

return
%==========================================================================
function [val,fid] = ReadDouble( fid,valueLength )
%READDOUBLE
%   DESCRIPTION:
%       Read a value of class double from file.
%   INPUTS:
%       fid:
%           File identifier.
%       valueLength:
%           Number of characters in the file which specify the double
%           value.
%   OUTPUTS:
%       val:
%           Value of type double read from the file.
%       fid:
%           File identifier.
%   EXAMPLE:
%       [val,fid] = ReadDouble( fid,valueLength );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

fmt = sprintf('%%%df',valueLength);
val = double( fscanf(fid,fmt,1) );

return
%==========================================================================
function [val,fid] = ReadInteger( fid,valueLength )
%READINTEGER
%   DESCRIPTION:
%       Read a value of class integer from file.
%   INPUTS:
%       fid:
%           File identifier.
%       valueLength:
%           Number of characters in the file which specify the integer
%           value.
%   OUTPUTS:
%       val:
%           Value of type integer read from the file.
%       fid:
%           File identifier.
%   EXAMPLE:
%       [val,fid] = ReadInteger( fid,valueLength );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

fmt = sprintf('%%%dd',valueLength);
val = int32( fscanf(fid,fmt,1) );

return
%==========================================================================
function [fid,hdr] = ReadPhysioHeader( fid,headerSize )
%READPHYSIOHEADER
%   DESCRIPTION:
%       This function reads the physio header from a DICOM file. The physio
%       header should be either 16 or 32 bytes in size. The information
%       in the header is returned in a structure.
%   INPUTS:
%       fid:
%           File identifier.
%       headerSize:
%           Scalar value indicating header size. Valid values are either 16
%           or 32.
%   OUTPUTS:
%       fid:
%           File identifier.
%       hdr:
%           Structure with the following fields, whose class/size varies
%           depending on the size of the header.
%           Field        |  16-byte  |  32-byte
%           -------------|-----------|----------------
%           sampleTime   |  uint32   |  uint64
%           threeDPos    |  uint16   |  uint16
%           headerTag    |  uint16   |  uint16
%           dataType     |  uint16   |  uint16
%           dataFormat   |  uint16   |  uint16
%           pulseIndex   |  uint16   |  uint16
%           lineIndex    |  uint16   |  uint16
%   EXAMPLE:
%       [fid,hdr] = ReadPhysioHeader( fid,headerSize );
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

if headerSize==16
    %read in 16-byte header
    
    %sample time    (unsigned long int, 4 bytes)
    hdr.sampleTime = fread( fid,1,'uint32=>uint32' );
    
    %threeDPos      (unsigned short int, 2 bytes)
    hdr.threeDPos  = fread( fid,1,'uint16=>uint16' );
    
    %headertag      (unsigned short int, 2 bytes)
    hdr.headerTag  = fread( fid,1,'uint16=>uint16' );
    
    %data type      (unsigned short int, 2 bytes)
    hdr.dataType   = fread( fid,1,'uint16=>uint16' );
    
    %data format    (unsigned short int, 2 bytes)
    hdr.dataFormat = fread( fid,1,'uint16=>uint16' );
    
    %pulse index    (unsigned short int, 2 bytes)
    hdr.pulseIndex = fread( fid,1,'uint16=>uint16' );
    
    %line index     (unsigned short int, 2 bytes)
    hdr.lineIndex  = fread( fid,1,'uint16=>uint16' );
    
elseif headerSize==32
    %read in 32-byte header
    
    %sample time    (unsigned long int, 8 bytes)
    hdr.sampleTime = fread( fid,1,'uint64=>uint64' );
    
    %threeDPos      (unsigned short int, 2 bytes)
    hdr.threeDPos  = fread( fid,1,'uint16=>uint16' );
    
    %headertag      (unsigned short int, 2 bytes)
    hdr.headerTag  = fread( fid,1,'uint16=>uint16' );
    
    %data type      (unsigned short int, 2 bytes)
    hdr.dataType   = fread( fid,1,'uint16=>uint16' );
    
    %data format    (unsigned short int, 2 bytes)
    hdr.dataFormat = fread( fid,1,'uint16=>uint16' );
    
    %pulse index    (unsigned short int, 2 bytes)
    hdr.pulseIndex = fread( fid,1,'uint16=>uint16' );
    
    %line index     (unsigned short int, 2 bytes)
    hdr.lineIndex  = fread( fid,1,'uint16=>uint16' );
    
    %12 bytes of padding
    fread(fid,12,'uint8');
else
    error('ERROR: unknown header format for specified size');
end

return
%==========================================================================
function [fid,physioData] = ReadPhysioData( fid,dcmTags,const,physioData )
%READPHYSIODATA
%   DESCRIPTION:
%       This function reads in the information stored at the physio data
%       block (headers + recorded physio channels). The data is returned in
%       the physioData structure.
%   INPUTS:
%       fid:
%           File identifier for DICOM file containing scan line data.
%       dcmTags:
%           Array returned by the function 'ScanDICOMTags' which summarizes
%           the tags found in the DICOM, as well as related tag
%           information.
%       const:
%           Structure of pre-specified constants initialized in
%           DICOMPhysioReader.
%       physioData:
%           Structure as initialized in DICOMPhysioReader which stores
%           relevant information surrounding the recorded physio data.
%   OUTPUTS:
%       physioData:
%           Structure as initialized in DICOMPhysioReader which stores
%           relevant information surrounding the recorded physio data.
%   EXAMPLES:
%       [fid,physioData] = ReadPhysioData(fid,dcmTags,const,physioData);
%   AUTHOR:
%       Robert Schneider
%       Ultrasound Investigations
%       Philips Healthcare
%       April 2013

%find location of all sequence titles and find the one corresponding to the
%desired data
indPossible = FindMatchingTag( dcmTags,const.tags.native_data_type );

for n = 1:numel(indPossible)
    %seek to location in file of sequence
    fid = FileSeek2DCMTag( fid,dcmTags,indPossible(n) );
    
    %read title
    tempStr = fread( fid,dcmTags(indPossible(n),5),'uint8=>char' );
    tempStr = tempStr(:)';
    
    %compare strings to determine if it is the desired sequence
    if( strcmpi(tempStr,const.physio_sequence_title) )
        %found physio data...
        
        %find sequence start
        indSeqStart = FindMatchingTag( dcmTags,const.tags.seq_item,indPossible(n),[],1 );
        
                        
        %find sequence end
        indSeqEnd = FindMatchingTag( dcmTags,const.tags.seq_item_delim,indSeqStart,[],1 );
        
                      
        %read number of samples
        indTarget = FindMatchingTag( dcmTags,const.tags.num_samples,indSeqStart,indSeqEnd,1 );
        if isempty(indTarget)
            error('ERROR: could not find number of samples');
        end
        fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
        [tempNumSamples,fid] = ReadInteger( fid,dcmTags(indTarget,5) );
        
        
        %read number of bytes per sample
        indTarget = FindMatchingTag( dcmTags,const.tags.bytes_per_sample,indSeqStart,indSeqEnd,1 );
        if isempty(indTarget)
            error('ERROR: could not find sample size');
        end
        fid = FileSeek2DCMTag( fid,dcmTags,indTarget );
        [tempBytesPerSample,fid] = ReadInteger( fid,dcmTags(indTarget,5) );
        
        
        %determine if compression type is in sequence
        indCompType = FindMatchingTag( dcmTags,const.tags.compress_type,indSeqStart,indSeqEnd,1 );
        compType = [];
        if ~isempty(indCompType)
            %read in compression type
            fid = FileSeek2DCMTag( fid,dcmTags,indCompType );
            compType = fread(fid,dcmTags(indCompType,5),'uint8=>char');
            compType = compType(:)';
            if ~strcmpi(compType,'None')
                error('ERROR: unknown compression type for physio data');
            end
        end
        
        
        %determine if native headers are in sequence
        %(used later to determine how to read/parse physio data)
        indHeaders = FindMatchingTag( dcmTags,const.tags.native_headers,indSeqStart,indSeqEnd,1 );
        tempHeaderBytes = 16;
        if ~isempty(indHeaders)
            tempHeaderBytes = dcmTags(indHeaders,5)/tempNumSamples;
        end
        
        
        %determine type of data (old iE vs. new iE/Voyager) present
        indOldData = FindMatchingTag( dcmTags,const.tags.native_data_stream,indSeqStart,indSeqEnd,1 );
        indNewData = FindMatchingTag( dcmTags,const.tags.compress_native_data,indSeqStart,indSeqEnd,1 );
        if ~isempty(indOldData) && ~isempty(indNewData)
            error('ERROR: old and new data tags found');
        end
        if  isempty(indOldData) &&  isempty(indNewData)
            error('ERROR: neither old nor new data tags found');
        end
        
        
        %record sequence information read from file and initialize storage
        physioData.numSamples       = tempNumSamples;
        physioData.bytesPerSample   = tempBytesPerSample;
        physioData.bytesPerHeader   = tempHeaderBytes;
        physioData.time             = zeros(tempNumSamples,1);
        physioData.channels         = zeros(tempNumSamples,2+physioData.numTraces,'int16');
        physioData.heartRate        = zeros(tempNumSamples,1,'int16');
        physioData.isRPeak          = zeros(tempNumSamples,1,'uint8');
        physioData.isEndSystole     = zeros(tempNumSamples,1,'uint8');
        
        %read physio data
        if ~isempty(indOldData)
            %read in old format data
            %[header - data - header - data ...]
            
            %seek to location at the beginning of the data block
            fid = FileSeek2DCMTag( fid,dcmTags,indOldData );
            startPos = ftell(fid);
            
            %read in headers and volume data
            for s = 1:tempNumSamples
                %seek to location of sample
                fseek(fid,startPos+tempBytesPerSample*s,'bof');
                
                %read in header and record
                [fid,tempHeader] = ReadPhysioHeader(fid,tempHeaderBytes);
                physioData.headers{s} = tempHeader;
                
                %record time
                physioData.time(s) = tempHeader.sampleTime;
                
                %determine if R-Peak detected at point
                physioData.isRPeak(s) = bitget(tempHeader.dataFormat,7);
                
                %determine if ES detected at sample
                physio.isEndSystole(s) = bitget(tempHeader.dataFormat,14);
                
                %read physio channels and heart rate
                if physioData.numTraces>1
                    chans = fread(fid,9,'int16=>int16');
                else
                    chans = fread(fid,3,'int16=>int16');
                end
                physioData.channels(s,1:physioData.numTraces) = chans(1:physioData.numTraces)';
                physioData.channels(s,end-1:end) = chans(end-1:end)';
                physioData.heartRate(s) = fread(fid,1,'int16=>int16');
                
            end
        else
            %read in new format data
            %[stream size - num samples - offset table - header - data - header - data ...]
            
            %seek to location at the beginning of the data block
            fid = FileSeek2DCMTag( fid,dcmTags,indNewData );
            startPos = ftell(fid);
            
            %read in number of bytes of data
            %(NOTE: this may not coincide with the value length as the
            %       value length has to be an even number)
            nBytesData = fread(fid,1,'uint32=>uint32');
            
            %read in number of samples
            numSamplesHdr = fread(fid,1,'uint32=>uint32');
            
            %read in offset table
            offsets = zeros(1,tempNumSamples);
            for s = 1:tempNumSamples
                offsets(s) = fread(fid,1,'uint32=>uint32');
            end
            
            %read in headers and volume data and uncompress data
            for s = 1:tempNumSamples
                %seek to file location for desired frame
                fseek( fid,startPos + offsets(s),'bof' );
                
                %read in header and record
                [fid,tempHeader] = ReadPhysioHeader(fid,tempHeaderBytes);
                physioData.headers{s} = tempHeader;
                
                %record time
                physioData.time(s) = tempHeader.sampleTime;
                
                %determine if R-Peak detected at sample
                physioData.isRPeak(s) = bitget(tempHeader.dataFormat,7);
                
                %determine if ES detected at sample
                physio.isEndSystole(s) = bitget(tempHeader.dataFormat,14);
                
                %read physio channels and heart rate
                if physioData.numTraces>1
                    chans = fread(fid,9,'int16=>int16');
                else
                    chans = fread(fid,3,'int16=>int16');
                end
                physioData.channels(s,1:physioData.numTraces) = chans(1:physioData.numTraces)';
                physioData.channels(s,end-1:end) = chans(end-1:end)';
                physioData.heartRate(s) = fread(fid,1,'int16=>int16');

            end
        end
        
        %determine if should get rid of last point (sometimes data type
        %changes and sample is a bad sample)
        if physioData.numSamples>0
            if physioData.headers{end}.dataType~=physioData.headers{1}.dataType
                %remove sample
                physioData.headers(end) = [];
                physioData.time(end) = [];
                physioData.isRPeak(end) = [];
                physioData.isEndSystole(end) = [];
                physioData.channels(end,:) = [];
                physioData.heartRate(end) = [];
                physioData.numSamples = physioData.numSamples-1;
            end
        end

        %if go to this point then found data... break from loop
        break;
    end
end

return
%==========================================================================