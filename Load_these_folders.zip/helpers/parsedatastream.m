function [hdr,dataout] = parsedatastream(native,i1)
%PARSEDATASTREAM Summary of this function goes here
%   Detailed explanation goes here


% parse header, from Rob Schneider
 %frame time     (uint64, 8 bytes)
hdr.frameTime  = typecast(uint8(native.compressedheaderstream{i1}(1:8)),'uint64');
    %reserved       (unsigned short int, 2 bytes)
hdr.reserved1  = typecast(uint8(native.compressedheaderstream{i1}(9:10)),'uint16');
    %headertag (:14) + elastosign (:2) (unsigned short int, 2 bytes)
hdr.headerTag  = typecast(uint8(native.compressedheaderstream{i1}(11:12)),'uint16');        
    %data type      (uchar, 1 byte)
hdr.dataType  = uint8(native.compressedheaderstream{i1}(13));
    %reserved       (uchar, 1 byte)
hdr.reserved2  = char(uint8(native.compressedheaderstream{i1}(14)));    
%data format    (unsigned short int, 2 bytes)
hdr.dataFormat = typecast(uint8(native.compressedheaderstream{i1}(15:16)),'uint16');  
%data size      (unsigned long int, 4 bytes)
hdr.dataSize   = typecast(uint8(native.compressedheaderstream{i1}(17:20)),'uint32');
%NOTE: in frustum volume data, it is observed that dataSize = rPitch*thetaPitch*phiCount   
   

headersize = 32;
cds.datalength = typecast(uint8(native.compresseddatastream{i1}(1:4)),'uint32');
cds.numframes = typecast(uint8(native.compresseddatastream{i1}(5:8)),'uint32');
cds.frameoffsettable = typecast(uint8(native.compresseddatastream{i1}(9:(9+cds.numframes*4-1))),'uint32');
cds.frameoffsettable = cds.frameoffsettable+1;
for i2 = 1:length(cds.frameoffsettable)
    cds.frameheaders{i2} = native.compresseddatastream{i1}(cds.frameoffsettable(i2):cds.frameoffsettable(i2)+31);
end
for i2 = 1:length(cds.frameoffsettable)-1    
    cds.framedata{i2} = native.compresseddatastream{i1}(cds.frameoffsettable(i2)+headersize:cds.frameoffsettable(i2+1)-1);
end
   cds.framedata{i2+1} = native.compresseddatastream{i1}(cds.frameoffsettable(end)+headersize:length(native.compresseddatastream{i1}));

dataout = zeros(hdr.dataSize,length(cds.framedata));
for i100 = 1:size(dataout,2)
    tmp = ZLibDecompress(cds.framedata{i100});
    dataout(:,i100) = tmp(1:hdr.dataSize);
end

end

