function outData = ZLibDecompress(inData)
%ZLIBDECOMPRESS
%   DESCRIPTION:
%       This function will decompress data that was compressed using a ZLib
%       compression algorithm (lossless compression). This can be used to
%       decompress cartesian DICOM data in compressed Philips DICOM files.
%   INPUTS:
%       inData:
%           Input data that was compressed using a ZLib compression
%           algorithm
%   OUTPUTS:
%       outData:
%           Decompressed version of the input data
%   EXAMPLES
%       outData = ZLibDecompress( inData );
%   AUTHOR:
%       Doug Perrin, Children's Hospital, September 2011

import com.mathworks.mlwidgets.io.InterruptibleStreamCopier

a   = java.io.ByteArrayInputStream( inData );
b   = java.util.zip.InflaterInputStream( a );
isc = InterruptibleStreamCopier.getInterruptibleStreamCopier;
c   = java.io.ByteArrayOutputStream;

isc.copyStream( b,c );

outData = typecast( c.toByteArray,'uint8' );

return
