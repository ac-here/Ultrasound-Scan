function dicom_info = ScanDICOMTags( varargin )
%SCANDICOMTAGS
%   DESCRIPTION:
%       This function scans the tags in a DICOM file and returns the tag
%       information for all the tags found.  Additionally, the tag info
%       can be displayed to the screen in a more recognizable format.
%   INPUTS:
%       filename (optional):
%           Name of the DICOM file. If filename is not provided, user will
%           be prompted to specify file location via a graphical interface.
%       disp_tag (optional):
%           Flag indicating how to capture the parsing information.
%           0: do not print parsing to screen or to file (default)
%           1: print parsing to screen
%           2: print parsing to file
%       stop_tag (optional):
%           Indicates a tag (GROUP,ELEMENT) after which the scan of the
%           DICOM file can be stopped. The tag should be a decimal
%           conversion of the hexadecimal tag representation.
%   OUTPUTS:
%       dicom_info:
%           Tag information for each tag.  Information is stored in an
%           array in double format and arranged according to the following:
%           [ GROUP ELEMENT VR[1x2] VL OFFSET SQ_FLAG ],
%           where GROUP   = 1st hexadecimal component of the tag (decimal representation)
%                 ELEMENT = 2nd hexadecimal component of the tag (decimal representation)
%                 VR      = value representation (decimal representation)
%                 VL      = value length
%                 OFFSET  = position of tag data from beginning of file
%                 SQ_FLAG = indicates if start(1), end(-1) of sequence or
%                           otherwise(0)
%   EXAMPLES:
%       dicom_info = ScanDICOMTags;
%       dicom_info = ScanDICOMTags( filename );
%       dicom_info = ScanDICOMTags( filename,1 );
%       dicom_info = ScanDICOMTags( [],1 );
%       dicom_info = ScanDICOMTags( filename,0,stop_tag );
%       dicom_info = ScanDICOMTags( [],0,stop_tag );
%   AUTHORS:
%       Robert Schneider, Harvard University, May 2009

%set flag for display and get stop tag if provided
disp_tag = 0;
stop_tag = [];
if ~nargin
    [fn,pn] = uigetfile('*.*','Specify DICOM file to scan tags:');
    if isequal(pn,0)||isequal(fn,0)
        return;
    end
    filename = fullfile(pn,fn);
else
    filename = varargin{1};
    if isempty(filename)
        [fn,pn] = uigetfile('*.*','Specify DICOM file to scan tags:');
        if isequal(pn,0)||isequal(fn,0)
            return;
        end
        filename = fullfile(pn,fn);
    end
    if ~exist(filename,'file')
        error('ERROR: file does not exist');
    end
end
if nargin>1
    if ~isempty(varargin{2}), disp_tag = varargin{2}; end
end
if nargin>2
    if ~isempty(varargin{3}), stop_tag = varargin{3}; end
    if numel(stop_tag)~=2
        error('ERROR: Invalid ''stop_tag''');
    end
end

%initialize output file if need to print to file
fidOut = [];
if disp_tag==2
    [p,f,e] = fileparts(filename);
    outFn = fullfile(p,[f '_Parsing.txt']);
    fidOut = fopen(outFn,'w');
    if fidOut==-1
        error('ERROR: could not open file for writing');
    end
end

%initialize tab (used when displaying tag info)
tab_value = 0;

%initialize storage variable
%... will be arranged as follows [ TAG(1) TAG(2) VR(1) VR(2) VL offset_from_BOF SQ_FLAG ]
dicom_info = [];

%open file for reading
fid = fopen( filename,'r','l' );
if fid==-1
    error(['ERROR: The file ''' filename ''' could not be opened!']);
else
    %read in first 128 bytes of '0'
    junk = fread(fid,128,'uint8');
    %read in 'DICM' at beginning of file
    junk = fread(fid,4,'uint8');
    %start reading in tags

    while true
        %read in tag (TAG)
        group   = fread(fid,1,'uint16');
        if feof(fid), break; end
        element = fread(fid,1,'uint16');
        if feof(fid), break; end
        
        %read in value representation (VR)
        vr(1) = fread(fid,1,'uint8=>char');
        if feof(fid), break; end
        vr(2) = fread(fid,1,'uint8=>char');
        if feof(fid), break; end
        
        %read in value length... dependent on VR value
        if strcmpi(vr,'ob')||strcmpi(vr,'ow')||...
           strcmpi(vr,'of')||strcmpi(vr,'sq')||...
           strcmpi(vr,'un')||strcmpi(vr,'ut')
            %read in 2 reserved bytes
            junk = fread(fid,1,'uint16');
            if feof(fid), break; end
            %read in value length (32-bit unsigned int)
            vl = fread(fid,1,'uint32');
            if feof(fid), break; end
            if vl==4294967295, vl = -1; end %4294967295 = 0xFFFF FFFF
        else
            %read in value length (16-bit unsigned int)
            vl = fread(fid,1,'uint16');
            if feof(fid), break; end
        end
        
        %save info
        dicom_info = [dicom_info;...
                      double(group) double(element) double(uint8(vr)) double(vl) ftell(fid) 0];
        
        %display TAG, VR, and VL
        if disp_tag
            group_disp   = ['0000' num2str(dec2hex(group))  ];
            element_disp = ['0000' num2str(dec2hex(element))];
            group_disp   = group_disp(end-3:end);
            element_disp = element_disp(end-3:end);
            if disp_tag==1
                fprintf('(%s),(%s) %s %d\n',group_disp,element_disp,vr,vl);
                %disp(['(' group_disp '),(' element_disp ') ' vr ' ' num2str(vl)]);
            else
                fprintf(fidOut,'(%s),(%s) %s %d\r\n',group_disp,element_disp,vr,vl);
            end
        end
        
        %read values or skip values... dependent on whether sequence or not
        if strcmpi(vr,'sq')
            dicom_info(end,7) = 1;
            [dicom_info,fid,fidOut] = ScanDICOMSequenceTags( dicom_info,fid,vl,disp_tag,tab_value,stop_tag,fidOut );
            dicom_info(end,7) = -1;
        elseif vl==-1
            break;
        else              
            status = fseek(fid,ftell(fid)+vl,'bof');
        end
        if feof(fid), break; end
        
        %determine if should stop reading file (based on stop tag)
        if ~isempty(stop_tag)
            if ~isempty(stop_tag)
                if dicom_info(end,1)>stop_tag(1) &&...
                   ~isequal(dicom_info(end,1:2),[65534 57344]) &&... %0xFFFE,0xE000
                   ~isequal(dicom_info(end,1:2),[65534 57357]) &&... %0xFFFE,0xE00D
                   ~isequal(dicom_info(end,1:2),[65534 57565])       %0xFFFe,0xE0DD
                    if dicom_info(end,5)>0
                        break;
                    end
                elseif dicom_info(end,1)>=stop_tag(1) && dicom_info(end,2)>=stop_tag(2)  &&...
                      ~isequal(dicom_info(end,1:2),[65534 57344]) &&... %0xFFFE,0xE000
                      ~isequal(dicom_info(end,1:2),[65534 57357]) &&... %0xFFFE,0xE00D
                      ~isequal(dicom_info(end,1:2),[65534 57565])       %0xFFFe,0xE0DD
                    if dicom_info(end,5)>0
                        break;
                    end
                end
            end
        end
    end
    
    %close the file
    fclose(fid);
    if disp_tag==2
        fclose(fidOut);
    end
end
%==========================================================================
function [dicom_info,fid,fidOut] = ScanDICOMSequenceTags( dicom_info,fid,value_length,disp_tag,tab_value,stop_tag,fidOut )
%SCANDICOMSEQUENCETAGS
%   DESCRIPTION:
%       This function is used in 'ScanDICOMTags' to properly process tag
%       information stored in sequences, as sequences have a different tag
%       structure than the rest of the DICOM file
%   INPUTS:
%       dicom_info:
%           Tag information for the DICOM file being explored.
%           Information is stored in an array in double format and arranged
%           according to the following:
%           [ GROUP ELEMENT VR[1x2] VL OFFSET SQ_FLAG ],
%           where GROUP   = 1st hexadecimal component of the tag
%                 ELEMENT = 2nd hexadecimal component of the tag
%                 VR      = value represntation
%                 VL      = value length
%                 OFFSET  = position of tag data from beginning of file
%                 SQ_FLAG = indicates if start(1), end(-1) of sequence or
%                           otherwise(0)
%       fid:
%           CURRENT file identifier for the DICOM file being explored.
%       value_length:
%           Number of bytes of the sequence being explored.
%       disp_tag:
%           Flag indicating whether to display tag info (0=NO; 1=YES)
%           If the flag is not defined, it assumed to be 0.
%       tab_value:
%           Used when displaying tag information, this indicates the number
%           of spaces to tab over when displaying information
%       stop_tag:
%           Indicates a tag (GROUP,ELEMENT) after which the scan of the
%           DICOM file can be stopped. The tag should be a decimal
%           conversion of the hexadecimal tag representation. If empty,
%           then scanning will not be stopped.
%       fidOut:
%           File position indicator for text file that parsing information
%           is getting written to (if writing to file). If no file is being
%           written, this should be blank.
%   OUTPUTS:
%       dicom_info:
%           Tag information for the DICOM file being explored.
%           Information is stored in an array in double format and arranged
%           according to the following:
%           [ GROUP ELEMENT VR[1x2] VL OFFSET SQ_FLAG ],
%           where GROUP   = 1st hexadecimal component of the tag
%                 ELEMENT = 2nd hexadecimal component of the tag
%                 VR      = value representation
%                 VL      = value length
%                 OFFSET  = position of tag data from beginning of file
%                 SQ_FLAG = indicates if start(1), end(-1) of sequence or
%                           otherwise(0)
%       fid:
%           CURRENT file identifier for the DICOM file being explored.
%       fidOut:
%           File position indicator for text file that parsing information
%           is getting written to (if writing to file). If no file is being
%           written, this should be blank.
%   EXAMPLES:
%       [dicom_info,fid,fidOut] = ScanDICOMSequenceTags( dicom_info,fid,value_length,disp_tag,tab_value,fidOut )
%   AUTHORS:
%       Robert Schneider, Harvard University, May 2009

%increment tab
tab_value = tab_value + 5;

%determine current position in the file
pos_start = ftell(fid);

while ~feof(fid)
    %read in tag
    group   = fread(fid,1,'uint16');
    element = fread(fid,1,'uint16');
    if feof(fid)
        break;
    end
    
    %read in subsequent data depending on tag
    if (group==65534)&&(element==57344) %G: 0xFFFe=65534,E: 0xE000=57344
        %assign empty VR because one does not exist for this tag
        vr = uint8('  ');
        %read in item length
        vl = fread(fid,1,'uint32');
        if vl==4294967295, vl = -1; end %4294967295 = 0xFFFF FFFF
        
        %save info
        dicom_info = [dicom_info;...
                      double(group) double(element) double(uint8(vr)) double(vl) ftell(fid) 0];
                  
        if disp_tag
            %display TAG and VL
            group_disp   = ['0000' num2str(dec2hex(group))  ];
            element_disp = ['0000' num2str(dec2hex(element))];
            group_disp   = group_disp(end-3:end);
            element_disp = element_disp(end-3:end);
            if disp_tag==1
                fprintf('%s(%s),(%s) %s %d\n',char(32*ones([1 tab_value])),group_disp,element_disp,vr,vl);
                %disp([char(32*ones([1 tab_value])) '(' group_disp '),(' element_disp ') ' vr ' ' num2str(vl)]);
            else
                fprintf(fidOut,'%s(%s),(%s) %s %d\r\n',char(32*ones([1 tab_value])),group_disp,element_disp,vr,vl);
            end
        end
    else
        %read in VR
        vr = fread(fid,2,'uint8=>char')';

        %read in value length... dependent on VR value
        if strcmpi(vr,'ob')||strcmpi(vr,'ow')||...
           strcmpi(vr,'of')||strcmpi(vr,'sq')||...
           strcmpi(vr,'un')||strcmpi(vr,'ut')

            %read in 2 reserved bytes
            junk = fread(fid,1,'uint16');
            %read in value length (32-bit unsigned int)
            vl = fread(fid,1,'uint32');
            if vl==4294967295, vl = -1; end %4294967295 = 0xFFFF FFFF
        else
            %read in value length (16-bit unsigned int)
            vl = fread(fid,1,'uint16');
        end

        %save info
        dicom_info = [dicom_info;...
                      double(group) double(element) double(uint8(vr)) double(vl) ftell(fid) 0];
        
        if disp_tag
            %display TAG, VR, and VL
            group_disp   = ['0000' num2str(dec2hex(group))  ];
            element_disp = ['0000' num2str(dec2hex(element))];
            group_disp   = group_disp(end-3:end);
            element_disp = element_disp(end-3:end);
            if disp_tag==1
                fprintf('%s(%s),(%s) %s %d\n',char(32*ones([1 tab_value])),group_disp,element_disp,vr,vl);
                %disp([char(32*ones([1 tab_value])) '(' group_disp '),(' element_disp ') ' vr ' ' num2str(vl)]);
            else
                fprintf(fidOut,'%s(%s),(%s) %s %d\r\n',char(32*ones([1 tab_value])),group_disp,element_disp,vr,vl);
            end
        end
        
        %read values or skip values... dependent on whether sequence or not
        if strcmpi(vr,'sq')
            dicom_info(end,7) = 1;
            [dicom_info,fid,fidOut] = ScanDICOMSequenceTags( dicom_info,fid,vl,disp_tag,tab_value,stop_tag,fidOut );
            dicom_info(end,7) = -1;
        else
            status = fseek(fid,ftell(fid)+vl,'bof');
        end
    end
    
    if value_length==-1
        %only exit after seeing FFFE,E0DD tag
        if (group==65534)&&(element==57565) %G: 0xFFFe=65534,E: 0xE0DD=57565
            break;
        end
    else
        %check position and detemine if should exit loop
        pos_current = ftell(fid);
        if (pos_current-pos_start)>=value_length
            break;
        end
    end
    
    %determine if should stop reading file (based on stop tag)
    if ~isempty(stop_tag)
        if dicom_info(end,1)>stop_tag(1) &&...
           ~isequal(dicom_info(end,1:2),[65534 57344]) &&... %0xFFFE,0xE000
           ~isequal(dicom_info(end,1:2),[65534 57357]) &&... %0xFFFE,0xE00D
           ~isequal(dicom_info(end,1:2),[65534 57565])       %0xFFFe,0xE0DD
            if dicom_info(end,5)>0
                break;
            end
        elseif dicom_info(end,1)>=stop_tag(1) && dicom_info(end,2)>=stop_tag(2)  &&...
              ~isequal(dicom_info(end,1:2),[65534 57344]) &&... %0xFFFE,0xE000
              ~isequal(dicom_info(end,1:2),[65534 57357]) &&... %0xFFFE,0xE00D
              ~isequal(dicom_info(end,1:2),[65534 57565])       %0xFFFe,0xE0DD
            if dicom_info(end,5)>0
                break;
            end
        end
    end
    
end

return
    
    