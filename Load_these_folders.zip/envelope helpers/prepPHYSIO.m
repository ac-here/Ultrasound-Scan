%%IMport text file data
STACK=[];
nPAD = 200; STACK.INFO.tdECG = 100; %time delay in ms before Rpeak to parse ECG
STACK.INFO.pID = 10;
STACK.INFO.sID = 2;
STACK.INFO.side = 'R'; %L: 0, R:1;
STACK.INFO.isART = 0;
STACK.INFO.isICA = 0;
dirtxt = dir(sprintf('*%sdata.txt',STACK.INFO.side));
fid = fopen(dirtxt(1).name); C = {''}; lines = 0;
    while ~numel(strfind(fgetl(fid),'X_Value'))
        lines = lines+1;
    end
    fclose(fid)
    fid = fopen(dirtxt(1).name);
    C = textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f','Delimiter','\t','HeaderLines',lines+1);
    X_Value = C{1};
    DWL     = C{2};
    nABP     = C{4};
    ECGII     = C{6};
    ART     = C{10};
    SP02     = C{12};
    CVP     = C{16};
    ICP1     = C{18};
    fclose(fid);


figure; 
plot(X_Value,ART/max(ART)); hold on;
plot(X_Value,CVP/max(CVP)); hold on;
plot(X_Value,ECGII/max(ECGII)); hold on;
plot(X_Value,nABP/max(nABP)); hold on;
plot(X_Value,SP02/max(SP02)); hold on;
plot(X_Value,ICP1/max(ICP1)); hold on;
plot(X_Value,DWL/max(DWL)); hold on;
legend('ART','CVP','ECG','nABP','spo2','icp','dwl')


%% Import info
 dirinfo = dir(sprintf('*%sinfo.txt',STACK.INFO.side));
 fid = fopen(dirinfo(1).name); 
 C = textscan(fid,'%s %s','Delimiter',':','HeaderLines',0);
 STACK.INFO.ACQ.FIELDS = C{1};
  STACK.INFO.ACQ.DATA = C{2};
 fclose(fid);

%% Setup data structures

STACK.ECG.data = [];
    STACK.ECG.data2 = [];
    STACK.ECG.t = [];
    STACK.ECG.iR = [];
STACK.nABP.data = [];
STACK.CBFV.data = [];
STACK.ICP.data = [];
STACK.SP02.data = [];
STACK.CVP.data = [];

%get rpeak indices
iecg = ~isnan(ECGII);
STACK.ECG.t = X_Value(iecg);
STACK.ECG.data = ECGII(iecg);
wt = modwt(STACK.ECG.data,5);
wtrec = zeros(size(wt));
wtrec(4:5,:) = wt(4:5,:);
y = imodwt(wtrec,'sym4');
y = abs(y).^2;
[qrspeaks,STACK.ECG.iR] = findpeaks(y,'MinPeakHeight',0.1,'MinPeakDistance',5);
STACK.ECG.iR(STACK.ECG.data(STACK.ECG.iR)<0) = [];
figure; plot(STACK.ECG.t,STACK.ECG.data); hold on; plot(STACK.ECG.t(STACK.ECG.iR),STACK.ECG.data(STACK.ECG.iR),'ro');
%figure; plot(y); hold on; plot(STACK.ECG.iR,qrspeaks,'r.');

%stack ecg
STACK.ECG.data2 = zeros(length(STACK.ECG.iR)-1,nPAD);
STACK.t = X_Value(iecg); STACK.INFO.NdECG = ceil((STACK.INFO.tdECG/1000)/(STACK.t(2)-STACK.t(1)));
STACK.ECG.iP = STACK.ECG.iR-STACK.INFO.NdECG;
for i1=2:length(STACK.ECG.iR)-1
    N = STACK.ECG.iP(i1+1)-(STACK.ECG.iP(i1));
    STACK.ECG.data2(i1,1:N) = STACK.ECG.data((STACK.ECG.iP(i1)):(STACK.ECG.iP(i1+1)-1));
    fprintf('\n %u, %u to %u',i1,STACK.ECG.iP(i1),(STACK.ECG.iP(i1+1)-1));
end

%stack nABP
STACK.nABP.data = nABP(iecg);
STACK.nABP.data2 = zeros(length(STACK.ECG.iP)-1,nPAD);
STACK.nABP.avg = zeros(length(STACK.ECG.iP)-1,1);
for i1=2:length(STACK.ECG.iP)-1
    N = STACK.ECG.iP(i1+1)-(STACK.ECG.iP(i1));
    STACK.nABP.data2(i1,1:N) = STACK.nABP.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1));
    STACK.nABP.avg(i1,1) = mean(STACK.nABP.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1)));
    fprintf('\n %u, %u to %u',i1,STACK.ECG.iP(i1),(STACK.ECG.iP(i1+1)-1));
end

%stack icp
STACK.ICP.data = ICP1(iecg);
STACK.ICP.data2 = zeros(length(STACK.ECG.iP)-1,nPAD);
STACK.ICP.avg = zeros(length(STACK.ECG.iP)-1,1);
for i1=2:length(STACK.ECG.iP)-1
    N = STACK.ECG.iP(i1+1)-(STACK.ECG.iP(i1));
    STACK.ICP.data2(i1,1:N) = STACK.ICP.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1));
    STACK.ICP.avg(i1,1) = mean(STACK.ICP.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1)));
    fprintf('\n %u, %u to %u',i1,STACK.ECG.iP(i1),(STACK.ECG.iP(i1+1)-1));
end

%stack sp02
STACK.SP02.data = SP02(iecg);
STACK.SP02.data2 = zeros(length(STACK.ECG.iP)-1,nPAD);
STACK.SP02.avg = zeros(length(STACK.ECG.iP)-1,1);
for i1=2:length(STACK.ECG.iP)-1
    N = STACK.ECG.iP(i1+1)-(STACK.ECG.iP(i1));
    STACK.SP02.data2(i1,1:N) = STACK.SP02.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1));
    STACK.SP02.avg(i1,1) = mean(STACK.SP02.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1)));
    fprintf('\n %u, %u to %u',i1,STACK.ECG.iP(i1),(STACK.ECG.iP(i1+1)-1));
end

%stack cbfv
%resample cbfv envelope
STACK.CBFV.data = interp1(double(t_spectrogram(idxPLOT)),envelope,X_Value(iecg),'linear');

STACK.CBFV.data2 = zeros(length(STACK.ECG.iP)-1,nPAD);
STACK.CBFV.avg = zeros(length(STACK.ECG.iP)-1,1);
for i1=2:length(STACK.ECG.iP)-1
    N = STACK.ECG.iP(i1+1)-(STACK.ECG.iP(i1));
    STACK.CBFV.data2(i1,1:N) = STACK.CBFV.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1));
    STACK.CBFV.avg(i1,1) = mean(STACK.CBFV.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1)));
    fprintf('\n %u, %u to %u',i1,STACK.ECG.iP(i1),(STACK.ECG.iP(i1+1)-1));
end

%stack arterial line
%resample cbfv envelope
STACK.ART.data = interp1(double(t_spectrogram(idxPLOT)),envelope,X_Value(iecg),'linear');

STACK.ART.data2 = zeros(length(STACK.ECG.iP)-1,nPAD);
STACK.ART.avg = zeros(length(STACK.ECG.iP)-1,1);
for i1=2:length(STACK.ECG.iP)-1
    N = STACK.ECG.iP(i1+1)-(STACK.ECG.iP(i1));
    STACK.ART.data2(i1,1:N) = STACK.ART.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1));
    STACK.ART.avg(i1,1) = mean(STACK.ART.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1)));
    fprintf('\n %u, %u to %u',i1,STACK.ECG.iP(i1),(STACK.ECG.iP(i1+1)-1));
end

%Stack tissue motion
[WM] = getTDwfm(SP,thresh,v_spectrogram);
STACK.WM.positive.data = interp1(double(t_spectrogram(idxPLOT)),v_spectrogram(WM.vP(idxPLOT)),X_Value(iecg),'linear');
STACK.WM.negative.data = interp1(double(t_spectrogram(idxPLOT)),v_spectrogram(WM.vN(idxPLOT)),X_Value(iecg),'linear');
STACK.WM.positive.data2 = zeros(length(STACK.ECG.iP)-1,nPAD);
STACK.WM.negative.data2 = zeros(length(STACK.ECG.iP)-1,nPAD);
STACK.WM.positive.avg = zeros(length(STACK.ECG.iP)-1,1);
STACK.WM.negative.avg = zeros(length(STACK.ECG.iP)-1,1);
for i1=2:length(STACK.ECG.iP)-1
    N = STACK.ECG.iP(i1+1)-(STACK.ECG.iP(i1));
    STACK.WM.positive.data2(i1,1:N) = STACK.WM.positive.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1));
    STACK.WM.negative.data2(i1,1:N) = STACK.WM.negative.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1));
    STACK.WM.positive.avg(i1,1) = mean(STACK.WM.positive.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1)));
    STACK.WM.negative.avg(i1,1) = mean(STACK.WM.negative.data(STACK.ECG.iP(i1):(STACK.ECG.iP(i1+1)-1)));
    fprintf('\n %u, %u to %u',i1,STACK.ECG.iP(i1),(STACK.ECG.iP(i1+1)-1));
end



%Plot everything
figure(102); 
subplot(331);
imagesc(STACK.ECG.data2');
title('ECG');

subplot(332);
imagesc(STACK.nABP.data2');
title('nABP');

subplot(333);
imagesc(STACK.ICP.data2');
title('ICP');

subplot(334);
imagesc(STACK.SP02.data2');
title('SP02');

subplot(335);
imagesc(STACK.CBFV.data2');
title('CBFV');

subplot(336);
imagesc(STACK.WM.positive.data2');
title('WM positive');

subplot(337);
imagesc(STACK.WM.negative.data2');
title('WM negative');

if isfield(STACK,'ART')
subplot(338);
    imagesc(STACK.WM.negative.data2');
title('Arterial Line');
end

% Save everything
save(fullfile('results',sprintf('stackeddata%s.mat',STACK.INFO.side)),'STACK');