function [WM] = getTDwfm(spect,thresh,v)
    spect = 2.^spect;
    thresh2 = repmat(thresh,[size(spect,1) 1]);
    spect2 = spect>(1.2*thresh2);
    spect2 = edge(spect2);
    WM.vP = zeros(1,size(spect,2));
    WM.vN = zeros(1,size(spect,2));
    WM.power = {};
    i0 = find(v==0);
    for i1 = 1:size(spect2,2)
        it = find(spect2(:,i1));
        %Get positive velocities
        iP = find(it>i0);
        if numel(iP)
            WM.vP(i1) = min(it(iP));
        else 
            WM.vP(i1) = i0;
        end
        %Get negative velocities
        iN = find(it<i0);
        if numel(iN)
            WM.vN(i1) = max(it(iN));
        else 
            WM.vN(i1) = i0;
        end
    end
    
    [PKSp,WM.iP]= findpeaks(WM.vP,'MinPeakProminence',5);
    [PKSn,WM.iN]= findpeaks(-WM.vN,'MinPeakProminence',5);
   
    %figure; imagesc(t_spectrogram,v_spectrogram,spect); hold on;
    %plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(envelope),'r-','LineWidth',2);hold on;
%             plot(t_spectrogram,v_spectrogram(WM.vP)); hold on; plot(t_spectrogram(WM.iP),v_spectrogram(PKSp),'ko');
%             hold on;  plot(t_spectrogram(WM.iP)-tDelay,v_spectrogram(envelope(PKSp)),'bo');
%             plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(WM.vN)); hold on; plot(t_spectrogram(WM.iN),-PKSn,'yo');
end