dirpatients = dir('Patient*');
processed ={};
for i1 = 12:length(dirpatients)
    cd(dirpatients(i1).name)
        dirstudies = dir('Study*');
        for i2 = 2:length(dirstudies)
            cd(dirstudies(i2).name)
                dir32b = dir('*.32B');
                for i3 = 1:length(dir32b)
                    fn = dir32b(i3).name;
                    processed{length(processed)+1} = fn;
                    processTCDV5;
                end
            cd ..
        end
    cd ..
end