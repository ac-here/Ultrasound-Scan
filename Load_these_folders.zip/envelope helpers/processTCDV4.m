%function [] = processTCDV2(fn)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Post-processing of Spectral Doppler IQ Data from CX-50
% Philips Research North America, 2016.
% Project: Non-invasive intracranial pressure monitoring
% Description: Using in-phase and quadrature data obtained from the
% backdoor of the CX-50 ultrasound system, compute and visualize
% spectrograms of cerebral blood flow velocitieresultss. Implement processing
% steps analogous to those implemented in the CX-50 for on-screen
% visualization.
% Date: Dec, 2015
% Edit: Jan, 2016, J. Sutton
% Edit: Apr, 2016, J. Sutton
warning('off','all');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%INPUTS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fn = uigetfile('.32B');   % IQ Data filename in CD
x = tic;
    fprintf('\n============================')    
    fprintf('\nRUNNING');
    fprintf('\n============================')
    fprintf('\nProcessing\t\tTime [s]')
    fprintf('\n----------------------------')
% CAS Processing
PARAMS.nsamples           = 128;          % Window size for spectrogram.
PARAMS.fracoverlap        = 0.75;         % Extent of window overlap
PARAMS.NFFT               = 1024;         % Zero-padding
PARAMS.thresh_spect       = 0.45;         % Noise rejection threshold.
PARAMS.size_SPfilt        = [20 20];      % Kernel size for median filter
PARAMS.fc                 = 1.8e6;        % Transmit center frequency 
PARAMS.ss                 = 1500;         % Assumed speed of sound [m/s]
PARAMS.angle              = 0;            % Doppler PARAMS.angle [deg]
PARAMS.fwc                = 100;          % Wall filter cutoff freq [Hz]
PARAMS.gain               = 1;            % Digital Gain
PARAMS.slidingwindowN     = 5;            % Sliding filter size, on average and envelope, odd
PARAMS.climit             = [0.25 0.53];  % Contrast visualization
PARAMS.vissigpath         = 0;            % Visualize high signal path

% spectral trace processing
PARAMS.samples_per_average = 3;
PARAMS.debug               = 0;
PARAMS.SNRmin              = 0.99;

% time vector analysis
PARAMS.CLINIC.good   = [6.925 8.000]*1e3;
PARAMS.CLINIC.SDgate = [6.000 6.925]*1e3;
PARAMS.CLINIC.CDroi  = [0.350 0.700]*1e3;
PARAMS.CLINIC.CDmode = [0.000 5.000]*1e3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%Load Data%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load time-stamped in-phase and quadrature data.
fprintf('\nLoading'); y = tic;
fileID=fopen(fullfile(fn),'r');
fprintf('\t\t\t\t%1.2f',toc(y));
fprintf('\nFormatting IQ'); y = tic;
TCD=fread(fileID,'int32','l');
TCD_length=length(TCD);
fclose(fileID);
%Load Time
t=TCD(1:4:TCD_length,1);
t = (t-t(1))/10^6; % Microsecond Time
%Load I
I=TCD(3:4:TCD_length,1);
%Load Q
Q=TCD(4:4:TCD_length,1);

%Just look at a few datapoints
t = t(1:50000);
I = I(1:50000);
Q = Q(1:50000);

%Save original timevector.
t0 = t;
%Upsample if necessary.
t2 = 0:min(diff(t)):t(end); t2 = t2';
I = interp1(t,I,t2,'linear');
Q = interp1(t,Q,t2,'linear');
t=t2; clear t2;
PARAMS.fs = 1/(t(10)-t(9)); % Get sampling frequency

%Pack
IQ   = complex(I,Q); clear I Q TCD;
fprintf('\t\t%2.2f',toc(y));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% Doppler Processing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Signal processing adapted from a written summary of doppler processing
% (FDS_Doppler.doc). The steps for Spectral Doppler display are
% 1. Apply high-pass wall filter.
% 2. Perform complex transformation to Fourier domain in slow time with sliding FFT (-DC to DC)
% 
% 3. Perform base-2 log compression.
% 4. Gain adjustment by user.
% 5. Pepper/Blur/Sharpness Filters to mitigate noise lobe visualization.
% 6. Derive noise threshold, apply to a 3 segment binary noise filter.
% 7. Convert to velocity and autoscale.

% Filter data.
[b a]= butter(2, PARAMS.fwc / (PARAMS.fs/2),'high'); %Cutoff frequency / Nyquist
IQ = single(filtfilt(b,a,IQ));
IQ_length=length(IQ);
IQ=IQ(1:floor(IQ_length/PARAMS.nsamples)*PARAMS.nsamples,1); %Cuts it off at the end by a small amount in order to have integer FFTs.
t = t(1:floor(IQ_length/PARAMS.nsamples)*PARAMS.nsamples);   %Cuts it off at the end by a small amount in order to have integer FFTs.
    if PARAMS.vissigpath
        fprintf('\nPlot IQ'); y = tic;
        figure(2); subplot(4,1,1);
        plot(t,real(IQ),t,imag(IQ));
        xlabel('Time [s]'); ylabel('Amplitude [A.U.]');
        axis tight; h1 = gca;
        fprintf('\t\t\t\t%2.2f',toc(y));
    end

% 0: good data
% 1: color-Doppler mode (dt>10)
% 2: color-Doppler box move
% 3: cursor move
fprintf('\nData quality'); y = tic;
 classify0 = zeros(size(t));
 tmp = zeros(size(t0));
 dt = diff(t0); dt = [dt(1); dt];
 %  idx = find(dt < 0.00015);
 %  classify(idx) = 0;
 
 %color-Doppler mode
 tmp = zeros(size(t0));
 idx = find(dt > 1);
 idx = find(dt > 1/PARAMS.CLINIC.CDmode(2) & dt < 1/PARAMS.CLINIC.CDmode(1)); 
 tmp(idx) = 1; 
 tmp1 = ceil(interp1(t0,tmp,t,'linear'));
 idxCD = find(tmp1);
 classify0(idxCD) = 3;
 
 %color-Doppler window move
 tmp = zeros(size(t0));
 idx = find(dt > 0.001 & dt < 1);
 idx = find(dt > 1/PARAMS.CLINIC.CDroi(2) & dt < 1/PARAMS.CLINIC.CDroi(1)); 
 tmp(idx) = 1; 
 tmp1 = ceil(interp1(t0,tmp,t,'linear'));
 idxCD = find(tmp1);
 classify0(idxCD) = 2;
 
 % cursor move
  tmp = zeros(size(t0));
 idx = find(dt > 0.0001444 & dt < 0.003);
 idx = find(dt > 1/PARAMS.CLINIC.SDgate(2) & dt < 1/PARAMS.CLINIC.SDgate(1)); 
 tmp(idx) = 1; 
 tmp1 = ceil(interp1(t0,tmp,t,'linear'));
 idxCD = find(tmp1);
 classify0(idxCD) = 1;
 
 if PARAMS.vissigpath
     figure; plot(t0,'.','Color',[200 200 200]/255);
     hold on; plot(t,'k.'); legstr = {'CX-50 Backdoor Timestamp','Good Data'};
     if numel(find(classify0==3)); hold on; plot(find(classify0==3),t(find(classify0==3)),'r.'); legstr{length(legstr)+1} = 'Color-Doppler Mode'; end
     if numel(find(classify0==2)); hold on; plot(find(classify0==2),t(find(classify0==2)),'g.'); legstr{length(legstr)+1} = 'Color-Doppler ROI Movement'; end
     if numel(find(classify0==1)); hold on; plot(find(classify0==1),t(find(classify0==1)),'m.'); legstr{length(legstr)+1} = 'Cursor Movement'; end
     legend(legstr);
 end
 clear tmp tmp1 dt;
 fprintf('\t\t%2.2f',toc(y));
 fprintf('\n\t%2.1f good data.',100*numel(find(classify0==0))./length(classify0));
 fprintf('\n\t%2.1f SD gate moving.',100*numel(find(classify0==1))./length(classify0));
 fprintf('\n\t%2.1f CD ROI moving.',100*numel(find(classify0==2))./length(classify0));
 fprintf('\n\t%2.1f CD mode.',100*numel(find(classify0==3))./length(classify0));
 
 
% Generate spectrogram consisting of sliding power spectral densities from complex IQ.
% Hanning window with considerable overlap
% Zero padding
        fprintf('\nGenerate spectra'); y= tic;
   [~,f_spectrogram,t_spectrogram,SP] = spectrogram(IQ, hann(PARAMS.nsamples),PARAMS.fracoverlap*PARAMS.nsamples, PARAMS.NFFT, PARAMS.fs, 'centered');
   classify1 = classify0(1:floor(length(t)/length(t_spectrogram)):length(classify0)); %resample the classification variable so that it is 1:1 with spectrogram time vector;
   classify1 = classify1(1:length(t_spectrogram)); %rounding error will toss a few samples on to the end, just chop.
        %Note: t_spectrogram will be (PARAMS.nsamples -
        %PARAMS.fracoverlap*PARAMS.nsamples)X smaller than the input size
        %of IQ
        fprintf('\t%2.2f',toc(y));
   %t_spectrogram = linspace(t(1),t(end),size(p,2));
   if PARAMS.vissigpath
        fprintf('\nPlot spectra');
        figure(2); subplot(4,1,2);
        imagesc(t_spectrogram,f_spectrogram,SP); colormap gray;
        xlabel('Time [s]'); ylabel('Frequency [Hz]');
   end
   
   
% Log2 compression 
   SP = log2(SP);
        if PARAMS.vissigpath
            figure(2); subplot(4,1,3);
            imagesc(t_spectrogram,f_spectrogram,SP); colormap gray;
            xlabel('Time [s]'); ylabel('Frequency [Hz]');
        end

% Gain adjustment
   SP = SP/max(SP(:));

% Salt and Pepper Filter
   SP = medfilt2(SP,PARAMS.size_SPfilt);
        if PARAMS.vissigpath
            figure(2); subplot(4,1,4);
            imagesc(t_spectrogram,f_spectrogram,SP); 
            colormap gray; 
            xlabel('Time [s]'); ylabel('Frequency [Hz]');
            fprintf('\t\t%2.2f',toc(y));
        end
 
% Spectrogram Visualization
% Derive threshold (currently done empirically)
% Apply noise mask.
    %SP(SP < PARAMS.thresh_spect) = 0.1;
       
% Convert frequency axis to velocity
   v_spectrogram = 100*f_spectrogram * PARAMS.ss/(2*PARAMS.fc*cosd(PARAMS.angle)); % Y axis. [cm/s]

% Autoscale, shift, and display.
if PARAMS.vissigpath
   figure(3); 
   imagesc(t_spectrogram, v_spectrogram, SP); 
   set(gca,'clim',PARAMS.climit);
   axis xy; colormap(gray);
   set(gca,'YDir','reverse');
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]');  
end

% Apply noise mask.
masktype = 'iterate';
switch masktype
    case 'iterate'
        fprintf('\nNoise mask(....'); y = tic;
        STATS_idx = zeros(2,round(size(SP,2)/1));
        thresh = zeros(1,size(STATS_idx,2));
        for idx = 1:size(STATS_idx,2) %5620
            if idx==910; 
            1;
            end
            if idx > 50 & idx < size(STATS_idx,2)-50 
                histlength = 100;
                tmp = 2.^SP(:,idx-20:idx+20);
                [X,N] = hist(tmp(:),histlength);
                coeff = ones(1, 10)/10;
                X2 = filter(coeff, 1, X); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.samples_per_average) = 0;
                fDelay = (length(coeff)-1)/2;
                N2 = circshift(N,round(fDelay),2);
                    [Maxima,MaxIdx] = findpeaks(X2(1:end),...
                                                        'MinPeakWidth',5,...
                                                        'MinPeakDistance',20,...
                                                        'MinPeakProminence',50);
                    DataInv = 1.01*max(X2) - X2;
                    [Minima,MinIdx] = findpeaks(DataInv(1:end),...
                                                        'MinPeakWidth',5,...
                                                        'MinPeakDistance',20,...
                                                        'MinPeakProminence',50);
                    Minima = X2(MinIdx);
                    
                p = polyfit(N2,X2,5);  
            else
                histlength = 100;
                tmp = 2.^SP(:,1:200);
                [X,N] = hist(tmp(:),histlength);
                coeff = ones(1, histlength/5)/(histlength/5);
                X2 = filter(coeff, 1, X); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.samples_per_average) = 0;
                fDelay = (length(coeff)-1)/2;
                N2 = circshift(N,round(fDelay),2);
                    [Maxima,MaxIdx] = findpeaks(X2(1:end),...
                                                        'MinPeakWidth',5,...
                                                        'MinPeakDistance',20,...
                                                        'MinPeakProminence',50);
                    DataInv = 1.01*max(X2) - X2;
                    [Minima,MinIdx] = findpeaks(DataInv(1:end),...
                                                        'MinPeakWidth',5,...
                                                        'MinPeakDistance',20,...
                                                        'MinPeakProminence',50);
                    Minima = X2(MinIdx);
                %figure(101);clf; plot(N,X); hold on; plot(N2,X2,'r.'); hold on; plot(N2(MinIdx),X2(MinIdx),'ro','MarkerFaceColor','k');title(sprintf('%f',idx)); drawnow; 
            end
            
            %Check threshold against noise magnitude
            [ymax,imax] = max(Maxima);
            if numel(MinIdx) == 0, MinIdx = MaxIdx(imax); end
            if MinIdx(end)<MaxIdx(imax), thresh(idx) = 0.95*N2(MaxIdx(imax)); 
            else thresh(idx) = 0.95*N2(MinIdx(end)); end
            figure(101);clf; 
                plot(N,X); hold on; plot(N2,X2,'r.'); hold on; plot(N2(MinIdx),X2(MinIdx),'ro','MarkerFaceColor','k'); title(sprintf('%f',idx)); 
                hold on; plot(N2(MaxIdx),X2(MaxIdx),'ro','MarkerFaceColor','g');
                hold on; plot([thresh(idx) thresh(idx)],[min(X2) max(X2)],'k-.'); drawnow;   
                
            %figure(201); clf; plot(thresh); drawnow;
            thresh(idx) = mean([N2(MinIdx) min(N2(MaxIdx))]); %jtsjan17
            [bin_final,STAT] = getPWtracemaskV3(2.^SP(:,idx),f_spectrogram,t_spectrogram(idx),PARAMS,thresh(idx));
            fprintf('\b\b\b\b%3.0f)',100*idx/size(SP,2));
            STATS_idx(1,idx) = STAT.imax;
            STATS_idx(2,idx) = STAT.imean;
        end
        fprintf('\t\t%3.2f',toc(y)');
        idxPLOT = linspace(1,size(STATS_idx,2),size(STATS_idx,2));
        idx100  = find(isnan(STATS_idx(2,:)));
        idxPLOT(idx100) = [];
        STATS_idx(:,idx100) = [];
        
        
        coeff = ones(1, PARAMS.slidingwindowN)/PARAMS.slidingwindowN;
        envelope = round(filter(coeff, 1, STATS_idx(1,:))); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.slidingwindowN) = 0;
        avg = round(filter(coeff, 1, STATS_idx(2,:))); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.slidingwindowN) = 0;
        fDelay = (length(coeff)-1)/2;
        if fDelay>0, tDelay = t_spectrogram(fDelay); else tDelay=0; end  
        
        if PARAMS.vissigpath
            figure(3); 
            hold on; plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(avg),'b-','LineWidth',2);
            hold on; plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(envelope),'r-','LineWidth',2);
        end
    case 'batch'
        %Run in batches of 1000
        batchsize = 10000;
        for idx50 = 1:ceil(size(SP,2)/10000)
            if idx50<ceil(size(SP,2)/10000)
                SP2 = SP(:,batchsize*(idx50-1)+1:idx50*batchsize);
            else
                SP2 = SP(:,batchsize*(idx50-1)+1:size(SP,2));
            end
            %SP2(SP2<sqrt((1/numel(SP2))*sum(2.^SP2(:).^2))) = 0;
            SP2(SP2<0.25) = 0;
            SP2 = medfilt2(SP2,2*PARAMS.size_SPfilt);
            [x, y] = find(edge(SP2,'sobel'));
            SP3 = poly2mask(y,x,size(SP2,1),size(SP2,2));
            env1 = []; env2 = []; idxenv = [];
            for idx5 = 1:size(SP3,2)
                [ix iy] = find(SP3(:,idx5));
                if numel(ix)>1
                    idxenv = [idxenv idx5];
                    [Y,I] = max(abs(f_spectrogram(ix)));
                    env1 = [env1 ix(I)];
                    [Y,I] = min(abs(f_spectrogram(ix)));
                    env2 = [env2 ix(I)];
                end
            end
            clear SP2 x y SP3;
        end   
end
if ~exist('result','dir'); 
    fprintf('\nCreating dirs'); y =tic;mkdir('results'); 
    fprintf('\t\t%1.2f',toc(y)');
end
fprintf('\nSaving env/avg'); y =tic;
if ~exist('results'), mkdir('results'); end
save(fullfile('results',sprintf('%s_env.mat',fn(1:end-4))),'avg','envelope','t_spectrogram','v_spectrogram','idxPLOT','tDelay','t0','t','classify0','classify1');
fprintf('\t\t%1.2f',toc(y)');
fprintf('\nSaving spectra'); y =tic;
save(fullfile('results',sprintf('%s_spect.mat',fn(1:end-4))),'SP');
% fid =fopen(fullfile('results',sprintf('%s_spect.bin',fn(1:end-4))),'w');
% fwrite(fid,SP(:),'uint16'); PARAMS.fclose(fid);
fprintf('\t\t%2.2f',toc(y)');
fprintf('\n============================')
fprintf('\nTotal time: %3.2fs',toc(x));
fprintf('\n(%3.2fs per s of TCD data)',toc(x)/t_spectrogram(end));
fprintf('\n============================\n')
%end
