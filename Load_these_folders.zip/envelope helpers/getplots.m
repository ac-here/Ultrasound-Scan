fs = [];
for idx = 1:length(t)-1
    fs(idx) = 1/(t(idx+1)-t(idx));
end

figure; subplot(1,2,1);
plot(t); hold on; plot(t_spectrogram); ylabel('Time Stamp [s]');
xlabel('Index');

hold on; subplot(1,2,2);
plot(fs); ylabel('PRF [Hz]');
xlabel('Index');


%%
t2 = 0:min(diff(t)):t(end); t2 = t2';
I2 = interp1(t,real(IQ),t2);
Q2 = interp1(t,imag(IQ),t2);

figure; 
plot(t); hold on;
plot(real(IQ)); hold on;
plot(imag(IQ)); hold on;