[PKS,LOCS]= findpeaks(-nabp(:,2),'MinPeakProminence',50);
figure; plot(nabp(:,2)); hold on; plot(LOCS,-PKS,'ro');

bp = zeros(200,length(LOCS));
bp(1:(LOCS(2)-LOCS(1)+1),1) = nabp(LOCS(1):LOCS(2),2);
for i2 = 2:length(LOCS)-1
    bp(1:(LOCS(i2+1)-LOCS(i2)+1),i2) = nabp(LOCS(i2):LOCS(i2+1),2);
end