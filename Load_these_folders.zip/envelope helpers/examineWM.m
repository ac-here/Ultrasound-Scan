i_v = zeros(size(wm,2),2);
for i1 = 1:size(wm,2)
    i_motion = find(wm(:,i1));
    if ~numel(i_motion), i_motion = round(size(wm,1)/2);end
    i_v(i1,:) = [i_motion(1) i_motion(end)];
        
end

figure; 
subplot(221);imagesc(t_spectrogram,v_spectrogram,SP); hold on; plot(t_spectrogram,v_spectrogram(i_v(:,1))); hold on; plot(t_spectrogram,v_spectrogram(i_v(:,2)));
title('wall velocity envelope');

subplot(222); imagesc(t_spectrogram,v_spectrogram,SP); set(gca,'XLim',[t_spectrogram(1) t_spectrogram(end)]);
hold on; h =plotyy(0,0,t_spectrogram,v_spectrogram(i_v)); %hold on; h =plotyy(0,0,t_spectrogram,v_spectrogram(i_v(:,2)));
set(h(1),'YLim',[-150 150]); set(h(2),'YLim',[-20 20]); 
set(h(1),'XLim',[t_spectrogram(1) t_spectrogram(end)]); set(h(2),'XLim',[t_spectrogram(1) t_spectrogram(end)]);
axis tight; title('max/min velocities');

vmax = v_spectrogram(i_v(:,1)); vmax = vmax-mean(vmax); vmin = v_spectrogram(i_v(:,2)); vmin = vmin-mean(vmin);
subplot(223); imagesc(t_spectrogram,v_spectrogram,SP); hold on; h =plotyy(0,0,t_spectrogram,[cumsum(vmin) cumsum(vmax)]); %hold on; h =plotyy(0,0,t_spectrogram,v_spectrogram(i_v(:,2)));
set(h(1),'YLim',[-150 150]); set(h(2),'YLim',[-500 500]); 
set(h(1),'XLim',[0 t_spectrogram(end)]); set(h(2),'XLim',[0 t_spectrogram(end)]);
axis tight; title('max/min displacement');

vmax = v_spectrogram(i_v(:,1)); vmax = vmax-mean(vmax); vmin = v_spectrogram(i_v(:,2)); vmin = vmin-mean(vmin);
subplot(224); imagesc(t_spectrogram,v_spectrogram,SP); hold on; h =plotyy(0,0,t_spectrogram,vmin-vmax); %hold on; h =plotyy(0,0,t_spectrogram,v_spectrogram(i_v(:,2)));
set(h(1),'YLim',[-150 150]); set(h(2),'YLim',[-8 16]); 
set(h(1),'XLim',[0 t_spectrogram(end)]); set(h(2),'XLim',[0 t_spectrogram(end)]);
axis tight; title('velocity of walls relative to one another');
