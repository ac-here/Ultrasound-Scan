[PKS,LOCS]= findpeaks(-double(v_spectrogram(envelope)),'MinPeakProminence',50);
figure; plot(v_spectrogram(envelope)); hold on; plot(LOCS,-PKS,'ro');

cbfv = zeros(200,length(LOCS));
cbfv(1:(LOCS(2)-LOCS(1)+1),1) = v_spectrogram(envelope(LOCS(1):LOCS(2)));
for i2 = 2:length(LOCS)-1
    cbfv(1:(LOCS(i2+1)-LOCS(i2)+1),i2) = v_spectrogram(envelope(LOCS(i2):LOCS(i2+1)))';
end
