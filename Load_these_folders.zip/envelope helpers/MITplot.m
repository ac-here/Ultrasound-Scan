%%
binfn = 'Patient10_H_HCP_BOLT_measurement2_L_MCA.32B';
envfn = [binfn(1:end-4) '_env.mat'];
spectfn = [binfn(1:end-4) '_spect.mat'];
load(fullfile('results',envfn));
load(fullfile('results',spectfn));
figure(601);
   subplot(2,1,1);
   imagesc(t_spectrogram, v_spectrogram, SP); 
   [N,X] = hist(SP(:)/max(SP(:)),50); 
   [Maxima,MaxIdx] = findpeaks(double(N),...
                            'MinPeakWidth',2,...
                            'MinPeakDistance',20,...
                            'MinPeakProminence',50);
   clim = get(gca,'clim');
   set(gca,'clim',[X(MaxIdx(1)) clim(2)]);
   axis xy; colormap(gray);
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]');  
   tplot = t_spectrogram(idxPLOT)-tDelay;
   vplot_avg = v_spectrogram(avg);
   vplot_env = v_spectrogram(envelope);
   classifyplot_i = find(classify1(idxPLOT) == 0);
   
   hold on; plot(tplot(classifyplot_i),vplot_avg(classifyplot_i),'b.','LineWidth',3);
   hold on; plot(tplot(classifyplot_i),vplot_env(classifyplot_i),'r.','LineWidth',3);
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]'); axis tight; legend('Average', 'Envelope');
   
   subplot(2,1,2);
   plot(t0,'.','Color',[200 200 200]/255);
   hold on; plot(t,'k.'); legstr = {'CX-50 Backdoor Timestamp','Good Data'};
   if numel(find(classify0==3)); hold on; plot(find(classify0==3),t(find(classify0==3)),'r.'); legstr{length(legstr)+1} = 'Color-Doppler Mode'; end
   if numel(find(classify0==2)); hold on; plot(find(classify0==2),t(find(classify0==2)),'g.'); legstr{length(legstr)+1} = 'Color-Doppler ROI Movement'; end
   if numel(find(classify0==1)); hold on; plot(find(classify0==1),t(find(classify0==1)),'m.'); legstr{length(legstr)+1} = 'Cursor Movement'; end
   legend(legstr,'Location','SouthEast'); axis tight;
   xlabel('IQ Time [Index]'); ylabel('IQ Time [s]');
   title(sprintf('%s',binfn));
   
fprintf('Data Quality');
fprintf('\n#########################');
fprintf('\n%2.3f good data.',100*numel(find(classify1==0))./length(classify1));
fprintf('\n%2.3f SD gate moving.',100*numel(find(classify1==1))./length(classify1));
fprintf('\n%2.3f CD ROI moving.',100*numel(find(classify1==2))./length(classify1));
fprintf('\n%2.3f CD mode.\n',100*numel(find(classify1==3))./length(classify1));


%Some interesting plots
%
figure; plot(flipud(unique(1./diff(t0))),'k.'); xlabel('Index of Unique Data Dump Frequencies'); ylabel('Frequency (Hz)');

   
%%
binfn = 'opt.32B';
envfn = [binfn(1:end-4) '_env.mat'];
spectfn = [binfn(1:end-4) '_spect.mat'];
load(fullfile('results',envfn));
load(fullfile('results',spectfn));
figure(401); 
   imagesc(t_spectrogram, v_spectrogram, 2.^SP); 
   %set(gca,'clim',[0.3 0.55]);
   axis xy; colormap(gray);
   %set(gca,'YDir','reverse');
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]');  
   hold on; plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(avg),'b-','LineWidth',3);
   hold on; plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(envelope),'r-','LineWidth',3);
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]'); axis tight; legend('Average', 'Envelope');
   
%% No index

binfn = 'opt.32B';
envfn = [binfn(1:end-4) '_env.mat'];
spectfn = [binfn(1:end-4) '_spect.mat'];
load(fullfile('results',envfn));
load(fullfile('results',spectfn));
figure(101); 
   imagesc(1:length(t_spectrogram), v_spectrogram, SP); 
   set(gca,'clim',[0.3 0.55]);
   axis xy; colormap(gray);
   %set(gca,'YDir','reverse');
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]');  
   hold on; plot(idxPLOT,v_spectrogram(avg),'b*','LineWidth',2);
   hold on; plot(idxPLOT,v_spectrogram(envelope),'r*','LineWidth',2);
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]'); axis tight; legend('Average', 'Envelope');