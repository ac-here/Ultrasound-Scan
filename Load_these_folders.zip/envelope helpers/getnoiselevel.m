function [level] = getnoiselevel(x,y)
%GETNOISELEVEL Summary of this function goes here
%   Detailed explanation goes here

[X,N] = hist(s_filtered,100);
[X,N] = hist(tmp(:),100);

interval = 80:87;
y = zeros(1,length(X));
x = 1:length(y);
y(interval) = X(interval);

pd = fitdist(X','Rayleigh');
y2 = pdf(pd,N);
plot(N,y2);

end

