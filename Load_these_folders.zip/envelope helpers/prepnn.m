
NNin = [];
NNout = [];
dirpatients = {'Patient10_H_HCP_BOLT_PHILIPS','Patient11_H_TBI_BOLT_PHILIPS'};
catlabel = [10 11]; CAT = [];
for idx0 = 1:length(dirpatients)
    cd(dirpatients{idx0});
    dirstudies = dir('Study*');
    for idx1 = 1:length(dirstudies)
        cd(dirstudies(idx1).name);
        dirstackeddata = dir(fullfile('results','stackeddata*.mat'));
        for idx = 1:length(dirstackeddata)
            load(fullfile('results',dirstackeddata(idx).name));
        %     %simple curve fitting
        %     NNin(1,:) = STACK.CBFV.avg;
        %     NNin(2,:) = STACK.nABP.avg;
        % 
        %     NNout = STACK.ICP.avg';

            %dynamic time series
            if STACK.INFO.isART
                tmp = [STACK.CBFV.data2(:,1:200) STACK.ART.data2(:,1:200)];
            else
                tmp = [STACK.CBFV.data2(:,1:200) STACK.nABP.data2(:,1:200)];
            end
            NNin = cat(1,tmp,NNin);
            NNout = cat(1,NNout,STACK.ICP.avg);
            CAT = cat(2,CAT,catlabel(idx0)*ones(1,size(STACK.CBFV.data2,1)));
        end
        cd ..
    end
    cd ..
end
% NNin = permute(NNin,[3 2 1]);
% NNin = reshape(NNin,[size(NNin,1) size(NNin,2) 1 size(NNin,3)]);
NNoutBINARY = zeros(size(NNout,1),30);
%NNin = NNin';
for idx10 = 1:size(NNoutBINARY,1)
    NNoutBINARY(idx10,round(NNout(idx10))+1) = 1;
end
%NNin = NNin/max(NNin(:));
%NNout = NNout/max(NNout);

NNin1 = NNin(find(CAT == 10),:);
NNin2 = NNin(find(CAT == 11),:);

NNout1 = NNoutBINARY(find(CAT == 10),:);
NNout2 = NNoutBINARY(find(CAT == 11),:);

%% LSTM
NNin = {};
NNout = {}; NNout = categorical(NNout);
dirstackeddata = dir('stackeddata*.mat');
for idx = 1:length(dirstackeddata)
    load(dirstackeddata(idx).name);
%     %simple curve fitting
%     NNin(1,:) = STACK.CBFV.avg;
%     NNin(2,:) = STACK.nABP.avg;
% 
%     NNout = STACK.ICP.avg';

    %dynamic time series
    NNin=[]; p = randperm(size(STACK.ICP.data2,1));
    for idx2= 1:size(STACK.ICP.data2,1)        
        NNin(:,:,1,p(idx2)) = [STACK.CBFV.data2(idx2,:); STACK.nABP.data2(idx2,:)];
    end
       % NNout = discretize(STACK.ICP.avg,10:15,'categorical',{'10','11','12','13','14'})';
         NNout = STACK.ICP.avg(p);
    
end

NNinTest = []; NNoutTest = [];
testvec = 500:599;
for idx3 = 1:length(testvec)
    NNinTest(:,:,1,idx3) = NNin(:,:,1,testvec(idx3));
    NNoutTest(:,:,idx3) = NNout(testvec(idx3),1);
end

%%
layers = [ ...
    imageInputLayer([1 200 1])
    %convolution2dLayer(1,1)
    %convolution2dLayer(1,1)
    fullyConnectedLayer(1)
    reluLayer
    fullyConnectedLayer(1)
    regressionLayer];
options = trainingOptions('sgdm','InitialLearnRate',0.001, 'MaxEpochs',10);
p = randperm(length(NNout));
Ntrain = floor(0.75*length(NNout));
net = trainNetwork(NNin(:,:,:,p(1:Ntrain)),NNout(p(1:Ntrain)),layers,options);
predictedNN = predict(net,NNin(:,:,1,p(Ntrain+1:end)));