[PKS,LOCS]= findpeaks(double(icp(:,2)),'MinPeakProminence',1.5);
figure; plot(icp(:,2)); hold on; plot(LOCS,PKS,'ro');

ICP = zeros(200,length(LOCS));
ICP(1:(LOCS(2)-LOCS(1)+1),1) = ICP(LOCS(1):LOCS(2));
for i2 = 2:length(LOCS)-1
    ICP(1:(LOCS(i2+1)-LOCS(i2)+1),i2) = icp(LOCS(i2):LOCS(i2+1),2)';
end
