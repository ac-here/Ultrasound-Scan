%function [] = processTCDV2(fn)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Post-processing of Spectral Doppler IQ Data from CX-50
% Philips Research North America, 2016.
% Project: Non-invasive intracranial pressure monitoring
% Description: Using in-phase and quadrature data obtained from the
% backdoor of the CX-50 ultrasound system, compute and visualize
% spectrograms of cerebral blood flow velocitieresultss. Implement processing
% steps analogous to those implemented in the CX-50 for on-screen
% visualization.
% Date: Dec, 2015
% Edit: Jan, 2016, J. Sutton
% Edit: Apr, 2016, J. Sutton
warning('off','all');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%INPUTS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fn = uigetfile('.32B');   % IQ Data filename in CD
x = tic;
    fprintf('\n============================')    
    fprintf('\nRUNNING');
    fprintf('\n============================')
    fprintf('\nProcessing\t\tTime [s]')
    fprintf('\n----------------------------')
% CAS Processing
PARAMS.nsamples           = 128;          % Window size for spectrogram.
PARAMS.fracoverlap        = 0.75;         % Extent of window overlap
PARAMS.NFFT               = 1024;         % Zero-padding
PARAMS.thresh_spect       = 0.45;         % Noise rejection threshold.
PARAMS.size_SPfilt        = [20 20];      % Kernel size for median filter
PARAMS.fc                 = 1.8e6;        % Transmit center frequency 
PARAMS.ss                 = 1500;         % Assumed speed of sound [m/s]
PARAMS.angle              = 0;            % Doppler PARAMS.angle [deg]
PARAMS.fwc                = 10;%00;          % Wall filter cutoff freq [Hz]
PARAMS.gain               = 1;            % Digital Gain
PARAMS.slidingwindowN     = 7;            % Sliding filter size, on average and envelope, odd
PARAMS.climit             = [0.25 0.53];  % Contrast visualization
PARAMS.vissigpath         = 0;            % Visualize high signal path
PARAMS.histfittype        = 'peaks';

% spectral trace processing
PARAMS.samples_per_average = 5;
PARAMS.debug               = 1;
PARAMS.SNRmin              = 0.99;
SP = (circshift(dataout{2}.img{1},round(size(dataout{2}.img{1},1)/2),1));
% Log2 compression 
   SP = log2(SP);

% Gain adjustment
   SP = SP/max(SP(:));

% Salt and Pepper Filter
   SP = medfilt2(SP,PARAMS.size_SPfilt);
 
% Spectrogram Visualization
% Derive threshold (currently done empirically)
% Apply noise mask.
    %SP(SP < PARAMS.thresh_spect) = 0.1;
       
% Autoscale, shift, and display.
if PARAMS.vissigpath
   figure(3); 
   imagesc(t_spectrogram, v_spectrogram, SP); 
   set(gca,'clim',PARAMS.climit);
   axis xy; colormap(gray);
   set(gca,'YDir','reverse');
   xlabel('Time [s]'); ylabel('Blood Velocity [cm/s]');  
end

% Apply noise mask.
masktype = 'iterate';
switch masktype
    case 'iterate'
        fprintf('\nNoise mask(....'); y = tic;
        STATS_idx = zeros(2,round(size(SP,2)/1));
        thresh = zeros(1,size(STATS_idx,2));
        for idx = 1:size(STATS_idx,2) %5620
            if idx==910; 
            1;
            end
            if idx > 20 & idx < size(STATS_idx,2)-20 
                histlength = 50;
                tmp = 2.^SP(:,idx-20:idx+20);
                [X,N] = hist(tmp(:),histlength);
                switch PARAMS.histfittype
                    case 'poly'
                        [Y,I] = max(X);
                        if I>5 && I<(length(N)-6)
                            P = polyfit(N(I-5:I+5),X(I-5:I+5),2);
                        else
                            P = polyfit(N,X,2);
                        end
                        q = 1.0:0.001:1.5;
                        g = polyval(P,q);
                        ii = find(g>0); xx = q(ii); yy = g(ii); 
                        if 1,
                            figure(101);clf;
                            plot(N,X); hold on; plot(xx,yy,'r-'); title(sprintf('%f',idx));
                        end
                        if numel(max(xx))
                            thresh(idx) = max(xx);
                        else
                            thresh(idx) = N(I);
                        end
                        hold on; plot([thresh(idx) thresh(idx)],[0 1000],'k-.'); drawnow;
                        %figure(201); clf; plot(thresh); drawnow;
                    case 'peaks'
                        coeff = ones(1, 10)/10;
                        X2 = filter(coeff, 1, X); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.samples_per_average) = 0;
                        fDelay = (length(coeff)-1)/2;
                        N2 = circshift(N,round(fDelay),2);
                        [Maxima,MaxIdx] = findpeaks(X2(1:end),...
                            'MinPeakWidth',5,...
                            'MinPeakDistance',20,...
                            'MinPeakProminence',50);
                        DataInv = 1.01*max(X2) - X2;
                        [Minima,MinIdx] = findpeaks(DataInv(1:end),...
                            'MinPeakWidth',5,...
                            'MinPeakDistance',20,...
                            'MinPeakProminence',50);
                        Minima = X2(MinIdx);
                        
                        p = polyfit(N2,X2,5);
                        %figure(101);clf; plot(N,X); hold on; plot(N2,X2,'r.'); hold on; plot(N2(MinIdx),X2(MinIdx),'ro','MarkerFaceColor','k');title(sprintf('%f',idx)); drawnow;
                        %Check threshold against noise magnitude
                        [ymax,imax] = max(Maxima);
                        if numel(MinIdx) == 0, MinIdx = MaxIdx(imax); end
                        if MinIdx(end)<MaxIdx(imax), thresh(idx) = 1.00*N2(MaxIdx(imax));
                        else thresh(idx) = 1.00*N2(MinIdx(end)); end
                        
                        if PARAMS.debug
                        figure(101);clf;
                        plot(N,X); hold on; plot(N2,X2,'r.'); hold on; plot(N2(MinIdx),X2(MinIdx),'ro','MarkerFaceColor','k'); title(sprintf('%f',idx));
                        hold on; plot(N2(MaxIdx),X2(MaxIdx),'ro','MarkerFaceColor','g');
                        hold on; plot([thresh(idx) thresh(idx)],[min(X2) max(X2)],'k-.'); drawnow;
                        end
                        %figure(201); clf; plot(thresh); drawnow;
                        thresh(idx) = mean([N2(MinIdx) min(N2(MaxIdx))]); %jtsjan17
                end
                
                
            else
                histlength = 50;
                tmp = 2.^SP(:,1:200);
                [X,N] = hist(tmp(:),histlength);
                coeff = ones(1, histlength/5)/(histlength/5);
                X2 = filter(coeff, 1, X); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.samples_per_average) = 0;
                fDelay = (length(coeff)-1)/2;
                N2 = circshift(N,round(fDelay),2);
                    [Maxima,MaxIdx] = findpeaks(X2(1:end),...
                                                        'MinPeakWidth',5,...
                                                        'MinPeakDistance',20,...
                                                        'MinPeakProminence',50);
                    DataInv = 1.01*max(X2) - X2;
                    [Minima,MinIdx] = findpeaks(DataInv(1:end),...
                                                        'MinPeakWidth',5,...
                                                        'MinPeakDistance',20,...
                                                        'MinPeakProminence',50);
                    Minima = X2(MinIdx);
                %figure(101);clf; plot(N,X); hold on; plot(N2,X2,'r.'); hold on; plot(N2(MinIdx),X2(MinIdx),'ro','MarkerFaceColor','k');title(sprintf('%f',idx)); drawnow; 
                %Check threshold against noise magnitude
                [ymax,imax] = max(Maxima);
                if numel(MinIdx) == 0, MinIdx = MaxIdx(imax); end
                if MinIdx(end)<MaxIdx(imax), thresh(idx) = 0.95*N2(MaxIdx(imax)); 
                else thresh(idx) = 0.95*N2(MinIdx(end)); end
                
                if PARAMS.debug
                figure(101);clf; 
                plot(N,X); hold on; plot(N2,X2,'r.'); hold on; plot(N2(MinIdx),X2(MinIdx),'ro','MarkerFaceColor','k'); title(sprintf('%f',idx)); 
                hold on; plot(N2(MaxIdx),X2(MaxIdx),'ro','MarkerFaceColor','g');
                hold on; plot([thresh(idx) thresh(idx)],[min(X2) max(X2)],'k-.'); drawnow;   
                end
                %figure(201); clf; plot(thresh); drawnow;
                thresh(idx) = mean([N2(MinIdx) min(N2(MaxIdx))]); %jtsjan17
            end
                       
            
            [bin_final,STAT] = getPWtracemaskV3(2.^SP(:,idx),v_spectrogram,t_spectrogram(idx),PARAMS,thresh(idx));
            fprintf('\b\b\b\b%3.0f)',100*idx/size(SP,2));
            STATS_idx(1,idx) = STAT.imax;
            STATS_idx(2,idx) = STAT.imean;
        end
        fprintf('\t\t%3.2f',toc(y)');
        idxPLOT = linspace(1,size(STATS_idx,2),size(STATS_idx,2));
        idx100  = find(isnan(STATS_idx(2,:)));
        idxPLOT(idx100) = [];
        STATS_idx(:,idx100) = [];
        
        
        coeff = ones(1, PARAMS.slidingwindowN)/PARAMS.slidingwindowN;
        envelope = round(filter(coeff, 1, STATS_idx(1,:))); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.slidingwindowN) = 0;
        avg = round(filter(coeff, 1, STATS_idx(2,:))); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.slidingwindowN) = 0;
        fDelay = (length(coeff)-1)/2;
        if fDelay>0, tDelay = t_spectrogram(fDelay); else tDelay=0; end  
        
        if PARAMS.vissigpath
            figure(3); 
            hold on; plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(avg),'b-','LineWidth',2);
            hold on; plot(t_spectrogram(idxPLOT)-tDelay,v_spectrogram(envelope),'r-','LineWidth',2);
        end
    case 'batch'
        %Run in batches of 1000
        batchsize = 10000;
        for idx50 = 1:ceil(size(SP,2)/10000)
            if idx50<ceil(size(SP,2)/10000)
                SP2 = SP(:,batchsize*(idx50-1)+1:idx50*batchsize);
            else
                SP2 = SP(:,batchsize*(idx50-1)+1:size(SP,2));
            end
            %SP2(SP2<sqrt((1/numel(SP2))*sum(2.^SP2(:).^2))) = 0;
            SP2(SP2<0.25) = 0;
            SP2 = medfilt2(SP2,2*PARAMS.size_SPfilt);
            [x, y] = find(edge(SP2,'sobel'));
            SP3 = poly2mask(y,x,size(SP2,1),size(SP2,2));
            env1 = []; env2 = []; idxenv = [];
            for idx5 = 1:size(SP3,2)
                [ix iy] = find(SP3(:,idx5));
                if numel(ix)>1
                    idxenv = [idxenv idx5];
                    [Y,I] = max(abs(f_spectrogram(ix)));
                    env1 = [env1 ix(I)];
                    [Y,I] = min(abs(f_spectrogram(ix)));
                    env2 = [env2 ix(I)];
                end
            end
            clear SP2 x y SP3;
        end   
end
if ~exist('result','dir'); 
    fprintf('\nCreating dirs'); y =tic;mkdir('results'); 
    fprintf('\t\t%1.2f',toc(y)');
end
fprintf('\nSaving env/avg'); y =tic;
if ~exist('results'), mkdir('results'); end
%save(fullfile('results',sprintf('%s_env.mat',fn(1:end-4))),'avg','envelope','t_spectrogram','v_spectrogram','idxPLOT','tDelay','t0','t','classify0','classify1','thresh');
fprintf('\t\t%1.2f',toc(y)');
fprintf('\nSaving spectra'); y =tic;
%save(fullfile('results',sprintf('%s_spect.mat',fn(1:end-4))),'SP');
% fid =fopen(fullfile('results',sprintf('%s_spect.bin',fn(1:end-4))),'w');
% fwrite(fid,SP(:),'uint16'); PARAMS.fclose(fid);
fprintf('\t\t%2.2f',toc(y)');
fprintf('\n============================')
fprintf('\nTotal time: %3.2fs',toc(x));
fprintf('\n(%3.2fs per s of TCD data)',toc(x)/t_spectrogram(end));
fprintf('\n============================\n')
%end
