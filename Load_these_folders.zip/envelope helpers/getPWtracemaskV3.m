function [bin_final,STAT] = getPWtracemaskV3(trace,f_spectrogram,currtime,PARAMS,thresh)
    coeff = ones(1, PARAMS.samples_per_average)/PARAMS.samples_per_average;
    s_filtered = filter(coeff, 1, trace); % sf_bg = s_filtered - mean(s_filtered(end-300:end)); sf_bg(1:PARAMS.samples_per_average) = 0;
    noise = s_filtered(5:255); %specify band to evaluate noise level
%     thresh     = sqrt(sum(noise.^2)/length(noise));
    fDelay = (length(coeff)-1)/2;
    s_bin = s_filtered > thresh;
    
    tmp = find(s_bin);
    if numel(tmp)
        fextent = max( abs( f_spectrogram([tmp(1) tmp(end)]) ) );
    else
        fextent = 0;
    end
    if max(s_filtered)/thresh < PARAMS.SNRmin || fextent<100  % Don't even analyze if the SNR is bad or frequency range isn't MCA relevant
        STAT.imean = nan;
        STAT.imax = nan;
        bin_final = [];
        return;
    end
    
    if PARAMS.debug
        fprintf('Currtime: %2.2f\n',currtime);
        %hold on; set(ha,'XData',currtime,'YData',200);
        figure(2); subplot(2,4,[1 5]); cla;
        plot(1:length(trace), trace,'k-'); hold on;
        plot((1:length(trace))-fDelay, s_filtered,'r-');
        axis tight; xlabel('Index'); ylabel('Spectral Power (A.U.)');

        figure(2); subplot(2,4,6); cla;
        plot(s_filtered,'k');
        hold on; plot(find(s_bin == 1),s_filtered(find(s_bin == 1)),'r.');

        subplot(2,4,2); cla;
        plot(s_bin,'r.'); axis tight; ylim([-0.5 1.5]);  
        xlabel('Index'); ylabel('Binary Value'); set(gca,'YTick',[0 1]);
        input('Press any key');
    end

    seg_start = [1; find(abs(diff(s_bin))>0.5)+1];
    seg_length = [seg_start(2:end); length(s_bin)] - seg_start;
    seg_type  = s_bin(seg_start);

    nsegs = length(seg_length);
    while length(seg_length) > 3
        %The following section makes false positives true before moving
        %forward
%             %Look at the negative segments
%             [Y,I] = sort(seg_length,1,'ascend');  
%             Itm = I.*~seg_type(I); %Get the index of false negative segments.
%             Itm = Itm(Itm>0); Itm = Itm(1);
%             if Itm == 1 || Itm == length(seg_type)
%             elseif seg_type(Itm(1)-1) && seg_type(Itm(1)+1) %if bounded by ones, make it a one
%                seg_length(Itm+1) = seg_length(Itm)+seg_length(Itm+1);
%             else
            %Look at the positive segments
            [Y,I] = sort(seg_length,1,'ascend');  
            Itm = I.*seg_type(I); %Get the index of false positive segments.
            Itm = Itm(Itm>0); %Don't choose negative segments.
            Itm=Itm(1); %Pick the leftmost segment.

            if Itm+1>length(seg_length)                                          %if its an end segment, push it to the previous segment
                seg_length(Itm-1) = seg_length(Itm)+seg_length(Itm-1);           
                seg_type(Itm-1)   = 0;
            elseif Itm-1<1                                                       %if its a beginning segment, push it to the next segment
                seg_length(Itm+1) = seg_length(Itm)+seg_length(Itm+1);
                seg_type(Itm+1)   = 0;
            elseif  seg_length(Itm-1)>seg_length(Itm+1)                          %if the previous was bigger, push it there                    
                seg_length(Itm-1) = seg_length(Itm)+seg_length(Itm-1);
                seg_type(Itm-1)   = 0;
            elseif  seg_length(Itm-1)<seg_length(Itm+1)
                seg_length(Itm+1) = seg_length(Itm)+seg_length(Itm+1);
                seg_type(Itm+1)   = 0;
            elseif  seg_length(Itm-1)==seg_length(Itm+1)
                seg_length(Itm+1) = seg_length(Itm)+seg_length(Itm+1);
                seg_type(Itm+1)   = 0;
            end
            %end
        %fprintf('Segment %1.0f (L=%3.0f) eliminated',Itm,seg_length(Itm));
            seg_length(Itm) = [];
            seg_type(Itm)   = []; 
        
        %Combine adjacents
        for idx2 = 1:length(seg_type)-1
            if length(seg_type) < 4 || length(seg_type) == idx2
                break;
            end
            if seg_type(idx2) == seg_type(idx2+1)
                seg_length(idx2) = seg_length(idx2) + seg_length(idx2+1);
                seg_type(idx2+1) = [];
                seg_length(idx2+1) = [];
            end
            
        end
    end
    if length(seg_length)<3, bin_final = zeros(length(f_spectrogram)-1,1);
    else
    bin_final = [zeros(1,seg_length(1)-round(fDelay)) ones(1,seg_length(2)+round(fDelay)) zeros(1,seg_length(3))]';
    end
    
    if  PARAMS.debug
    figure(2); subplot(2,4,7); cla;
    plot(s_filtered,'k');
    hold on; plot(find(bin_final == 1), s_filtered(find(bin_final == 1)),'b.'); 
    
    subplot(2,4,3); cla;
    plot(bin_final,'b.'); axis tight; ylim([-0.5 1.5]);  pause(1);
    xlabel('Index'); ylabel('Binary Value'); set(gca,'YTick',[0 1]);

    figure(2); subplot(2,4,[4 8]); cla;
    plot(trace,'k'); 
    hold on; plot(find(bin_final == 1),trace(find(bin_final == 1)),'m-');
    axis tight; 
    xlabel('Index'); ylabel('Spectral Power (A.U.)');
    drawnow;
    end
    
    % Determine if its mostly forward or backward flow.
    STAT.imask = find(bin_final);
    i_pos = find(f_spectrogram(STAT.imask)>0); i_pos = STAT.imask(i_pos);
    i_neg = find(f_spectrogram(STAT.imask)<0); i_neg = STAT.imask(i_neg);
    dirflow = mean(f_spectrogram(STAT.imask))>0;
    
    %STAT.imean = round(sum(trace(STAT.imask)/sum(trace(STAT.imask)).*STAT.imask)); %weighted avg.
    if ~numel(STAT.imask)
        STAT.imax = round(length(bin_final)/2);
        STAT.imean = STAT.imax;
    else
    switch dirflow
        case 1 % if waveform mostly positive flow   
        STAT.imax = STAT.imask(end);
        STAT.imean = round(sum(trace(i_pos)/sum(trace(i_pos)).*i_pos)); %weighted avg over posit
        case 0 % if waveform mostly negative flow   
        STAT.imax = STAT.imask(1);
        STAT.imean = round(sum(trace(i_neg)/sum(trace(i_neg)).*i_neg)); %weighted avg.
    end
    end
    %STAT.imean = round(sum(trace(STAT.imask)/sum(trace(STAT.imask)).*STAT.imask));  %weighted avg over full waveform
    if STAT.imean < 1
        1;
    end
    
end